// React Date Ultimate Fixer - Correction définitive des dates dans React
(function() {
    'use strict';
    
    console.log('REACT-DATE-FIXER: Initializing ultimate React date correction system...');
    
    // Configuration ultime pour les dates
    const REACT_DATE_CONFIG = {
        interceptAll: true,
        fixInvalidDates: true,
        fixNullUndefined: true,
        fixStringParsing: true,
        fixArrayMap: true,
        fallbackToNow: true,
        logErrors: false, // Désactiver le logging pour réduire la verbosité
        debugMode: false
    };
    
    // Fonction ultime pour corriger les dates
    function fixDateUltimate(value) {
        if (value === null || value === undefined) {
            if (REACT_DATE_CONFIG.fixNullUndefined) {
                if (REACT_DATE_CONFIG.logErrors) {
                    // Logs désactivés pour éviter la pollution de la console
                }
                return new Date();
            }
            return value;
        }
        
        // Si c'est déjà une date valide
        if (value instanceof Date) {
            if (isNaN(value.getTime())) {
                return new Date();
            }
            return value;
        }
        
        // Si c'est une chaîne
        if (typeof value === 'string') {
            // Dates ISO 8601 valides
            if (value.includes('T') && (value.includes('Z') || value.includes('+'))) {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                    return date;
                }
            }
            
            // Format YYYY-MM-DD
            if (/^\d{4}-\d{2}-\d{2}/.test(value)) {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                    return date;
                }
            }
            
            // Format français DD/MM/YYYY
            const frenchMatch = value.match(/(\d{2})\/(\d{2})\/(\d{4})/);
            if (frenchMatch) {
                const [, day, month, year] = frenchMatch;
                const isoDate = `${year}-${month}-${day}T00:00:00.000Z`;
                const date = new Date(isoDate);
                if (!isNaN(date.getTime())) {
                    return date;
                }
            }
            
            // Essayer parsing direct
            const date = new Date(value);
            if (!isNaN(date.getTime())) {
                return date;
            }
            
            // Si tout échoue
            return new Date();
        }
        
        // Si c'est un nombre
        if (typeof value === 'number') {
            const date = new Date(value);
            if (!isNaN(date.getTime())) {
                return date;
            }
            if (REACT_DATE_CONFIG.logErrors) {
                // Logs désactivés pour éviter la pollution de la console
            }
            return new Date();
        }
        
        // Autres types
        if (REACT_DATE_CONFIG.logErrors) {
            // Logs désactivés pour éviter la pollution de la console
        }
        return new Date();
    }
    
    // Intercepter l'objet Date natif
    function interceptDateConstructor() {
        if (!REACT_DATE_CONFIG.interceptAll) return;
        
        const OriginalDate = window.Date;
        
        // Remplacer le constructeur Date
        window.Date = function(...args) {
            if (args.length === 0) {
                return new OriginalDate(); // Date actuelle
            }
            
            if (args.length === 1) {
                return fixDateUltimate(args[0]);
            }
            
            // Pour 2+ arguments (year, month, day...)
            try {
                const date = new OriginalDate(...args);
                if (isNaN(date.getTime())) {
                    if (REACT_DATE_CONFIG.logErrors) {
                        console.warn('REACT-DATE-FIXER: Multi-arg Date failed → now', args);
                    }
                    return new OriginalDate();
                }
                return date;
            } catch (error) {
                if (REACT_DATE_CONFIG.logErrors) {
                    console.error('REACT-DATE-FIXER: Multi-arg Date error → now', args, error);
                }
                return new OriginalDate();
            }
        };
        
        // Copier toutes les propriétés statiques
        Object.setPrototypeOf(window.Date, OriginalDate);
        Object.getOwnPropertyNames(OriginalDate).forEach(name => {
            if (name !== 'prototype' && !(name in window.Date)) {
                window.Date[name] = OriginalDate[name];
            }
        });
        
        // Corriger Date.parse
        const originalParse = OriginalDate.parse;
        window.Date.parse = function(dateString) {
            try {
                const fixedDate = fixDateUltimate(dateString);
                return originalParse.call(OriginalDate, fixedDate);
            } catch (error) {
                if (REACT_DATE_CONFIG.logErrors) {
                    console.error('REACT-DATE-FIXER: Date.parse error → now', dateString, error);
                }
                return Date.now();
            }
        };
        
        // Corriger Date.UTC
        const originalUTC = OriginalDate.UTC;
        window.Date.UTC = function(...args) {
            try {
                return originalUTC.apply(OriginalDate, args);
            } catch (error) {
                if (REACT_DATE_CONFIG.logErrors) {
                    console.error('REACT-DATE-FIXER: Date.UTC error → now', args, error);
                }
                return Date.now();
            }
        };
        
        console.log('REACT-DATE-FIXER: Date constructor intercepted');
    }
    
    // Intercepter Array.prototype.map pour les dates
    function interceptArrayMap() {
        if (!REACT_DATE_CONFIG.fixArrayMap) return;
        
        const originalMap = Array.prototype.map;
        Array.prototype.map = function(callback, thisArg) {
            const newArray = originalMap.call(this, function(item, index, array) {
                try {
                    const result = callback.call(thisArg, item, index, array);
                    
                    // Si le résultat est une date invalide
                    if (result instanceof Date && isNaN(result.getTime())) {
                        if (REACT_DATE_CONFIG.logErrors) {
                            console.warn('REACT-DATE-FIXER: Invalid date in map fixed → now', item, result);
                        }
                        return new Date();
                    }
                    
                    return result;
                } catch (error) {
                    if (REACT_DATE_CONFIG.logErrors) {
                        console.error('REACT-DATE-FIXER: Map callback error for item', item, error);
                    }
                    return item; // Retourner l'item original
                }
            });
            
            return newArray;
        };
        
        console.log('REACT-DATE-FIXER: Array.map intercepted');
    }
    
    // Intercepter les fonctions React courantes
    function interceptReactFunctions() {
        try {
            // Intercepter React.createElement si disponible
            if (window.React && window.React.createElement) {
                const originalCreateElement = window.React.createElement;
                window.React.createElement = function(type, props, ...children) {
                    // Corriger les dates dans les props
                    if (props) {
                        Object.keys(props).forEach(key => {
                            if (props[key] instanceof Date && isNaN(props[key].getTime())) {
                                if (REACT_DATE_CONFIG.logErrors) {
                                    console.warn('REACT-DATE-FIXER: Invalid date in props fixed → now', key, props[key]);
                                }
                                props[key] = new Date();
                            }
                        });
                    }
                    
                    return originalCreateElement.call(this, type, props, ...children);
                };
                console.log('REACT-DATE-FIXER: React.createElement intercepted');
            }
            
            // Intercepter les hooks React si disponibles
            if (window.React && window.React.useState) {
                const originalUseState = window.React.useState;
                window.React.useState = function(initialValue) {
                    if (initialValue instanceof Date && isNaN(initialValue.getTime())) {
                        if (REACT_DATE_CONFIG.logErrors) {
                            console.warn('REACT-DATE-FIXER: Invalid date in useState fixed → now', initialValue);
                        }
                        return originalUseState.call(this, new Date());
                    }
                    return originalUseState.call(this, initialValue);
                };
                console.log('REACT-DATE-FIXER: React.useState intercepted');
            }
            
        } catch (error) {
            console.error('REACT-DATE-FIXER: Error intercepting React functions:', error);
        }
    }
    
    // Créer un wrapper pour les fonctions qui pourraient créer des dates
    function wrapFunctionsWithDateFixing() {
        // Intercepter setTimeout/setInterval si des callbacks créent des dates
        const originalSetTimeout = window.setTimeout;
        window.setTimeout = function(callback, delay, ...args) {
            const wrappedCallback = function(...args) {
                try {
                    return callback.apply(this, args);
                } catch (error) {
                    if (REACT_DATE_CONFIG.logErrors) {
                        console.error('REACT-DATE-FIXER: setTimeout callback error:', error);
                    }
                }
            };
            return originalSetTimeout.call(this, wrappedCallback, delay, ...args);
        };
        
        // Intercepter addEventListener pour les événements qui créent des dates
        const originalAddEventListener = EventTarget.prototype.addEventListener;
        EventTarget.prototype.addEventListener = function(type, listener, options) {
            const wrappedListener = function(event) {
                try {
                    return listener.call(this, event);
                } catch (error) {
                    if (REACT_DATE_CONFIG.logErrors) {
                        console.error('REACT-DATE-FIXER: Event listener error:', error);
                    }
                }
            };
            return originalAddEventListener.call(this, type, wrappedListener, options);
        };
        
        console.log('REACT-DATE-FIXER: Functions wrapped with date fixing');
    }
    
    // Créer le panneau de contrôle
    function createReactDatePanel() {
        setTimeout(() => {
            if (document.getElementById('react-date-fixer-panel')) return;
            
            const panel = document.createElement('div');
            panel.id = 'react-date-fixer-panel';
            panel.style.cssText = `
                position: fixed;
                top: 440px;
                right: 20px;
                width: 380px;
                background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
                color: white;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                z-index: 99992;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                animation: slideInRight 0.5s ease-out;
            `;
            
            panel.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0; font-size: 16px; font-weight: 600;">📅 React Date Fixer</h3>
                    <button onclick="this.parentElement.parentElement.remove()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 5px 10px; border-radius: 6px; cursor: pointer; font-size: 12px;">✕</button>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 15px;">
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Date Constructor</div>
                        <div style="font-size: 14px; font-weight: 600;">${REACT_DATE_CONFIG.interceptAll ? '✅ INTERCEPTED' : '❌ NORMAL'}</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Array.map Fix</div>
                        <div style="font-size: 14px; font-weight: 600;">${REACT_DATE_CONFIG.fixArrayMap ? '✅ ACTIVE' : '❌ INACTIVE'}</div>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 5px;">Current Time:</div>
                    <div id="current-time-display" style="font-size: 16px; font-weight: 600; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 6px;">
                        ${new Date().toLocaleString('fr-FR')}
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                    <button onclick="testDateFixing()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        🧪 Test Date Fix
                    </button>
                    <button onclick="testArrayMapFix()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        📋 Test Array Map
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr; gap: 10px;">
                    <button onclick="forceReactDateFix()" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); border: none; color: white; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
                        🛡️ FORCER CORRECTION DATES REACT
                    </button>
                </div>
                
                <div id="react-date-status" style="margin-top: 15px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 6px; font-size: 12px; display: none;">
                    <div id="react-date-status-content"></div>
                </div>
            `;
            
            // Ajouter le CSS
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
            
            document.body.appendChild(panel);
            
            // Mettre à jour l'heure toutes les secondes
            setInterval(() => {
                const timeDisplay = document.getElementById('current-time-display');
                if (timeDisplay) {
                    timeDisplay.textContent = new Date().toLocaleString('fr-FR');
                }
            }, 1000);
            
            // Fonctions globales
            window.testDateFixing = function() {
                showReactDateStatus('🧪 Test de correction de dates en cours...', 'info');
                
                const testCases = [
                    '2026-03-24T15:32:24.000Z',
                    '24/03/2026',
                    'invalid-date',
                    null,
                    undefined,
                    new Date('invalid'),
                    'not-a-date-at-all'
                ];
                
                const results = testCases.map(testCase => {
                    const fixed = fixDateUltimate(testCase);
                    return {
                        input: testCase,
                        output: fixed instanceof Date ? fixed.toISOString() : fixed,
                        valid: fixed instanceof Date && !isNaN(fixed.getTime())
                    };
                });
                
                setTimeout(() => {
                    const resultText = results.map(r => 
                        `${r.input} → ${r.valid ? '✅' : '❌'} ${r.output}`
                    ).join('\n');
                    
                    showReactDateStatus(`✅ Test terminé!\n\nRésultats:\n${resultText}`, 'success');
                }, 1000);
            };
            
            window.testArrayMapFix = function() {
                showReactDateStatus('📋 Test de correction Array.map en cours...', 'info');
                
                const testData = [
                    { id: 1, date: '2026-03-24T15:32:24.000Z' },
                    { id: 2, date: 'invalid-date' },
                    { id: 3, date: null },
                    { id: 4, date: undefined }
                ];
                
                try {
                    const results = testData.map(item => ({
                        ...item,
                        date: fixDateUltimate(item.date)
                    }));
                    
                    setTimeout(() => {
                        showReactDateStatus(`✅ Test Array.map réussi!\n\n${results.map(r => `ID ${r.id}: ${r.date.toISOString()}`).join('\n')}`, 'success');
                    }, 1000);
                    
                } catch (error) {
                    showReactDateStatus(`❌ Erreur dans Array.map: ${error.message}`, 'error');
                }
            };
            
            window.forceReactDateFix = function() {
                showReactDateStatus('🛡️ Force correction des dates React...', 'info');
                
                setTimeout(() => {
                    // Réinitialiser toutes les interceptions
                    interceptDateConstructor();
                    interceptArrayMap();
                    interceptReactFunctions();
                    wrapFunctionsWithDateFixing();
                    
                    showReactDateStatus('🛡️ Correction forcée appliquée!\n\n✅ Date constructor intercepté\n✅ Array.map corrigé\n✅ Fonctions React protégées\n✅ Wrappers activés\n\n🔄 Actualisation dans 2 secondes...', 'success');
                    
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                }, 1500);
            };
            
            console.log('REACT-DATE-FIXER: React date panel created');
        }, 8000);
    }
    
    // Afficher le statut
    function showReactDateStatus(message, type = 'info') {
        const statusDiv = document.getElementById('react-date-status');
        const contentDiv = document.getElementById('react-date-status-content');
        
        if (statusDiv && contentDiv) {
            statusDiv.style.display = 'block';
            contentDiv.innerHTML = `<div style="white-space: pre-line;">${message}</div>`;
            
            const colors = {
                success: 'rgba(16, 185, 129, 0.3)',
                error: 'rgba(239, 68, 68, 0.3)',
                info: 'rgba(59, 130, 246, 0.3)',
                warning: 'rgba(245, 158, 11, 0.3)'
            };
            statusDiv.style.background = colors[type] || colors.info;
        }
    }
    
    // Initialisation
    function initialize() {
        console.log('REACT-DATE-FIXER: Starting React date fixer initialization...');
        
        // Intercepter toutes les fonctionnalités
        interceptDateConstructor();
        interceptArrayMap();
        interceptReactFunctions();
        wrapFunctionsWithDateFixing();
        
        // Créer le panneau de contrôle
        createReactDatePanel();
        
        console.log('REACT-DATE-FIXER: React date fixer initialization complete');
    }
    
    // Démarrer l'initialisation
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
    
})();
