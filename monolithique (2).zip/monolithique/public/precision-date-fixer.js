// Precision Date Fixer - Correction précise des dates invalides dans Array.map
(function() {
    'use strict';
    
    console.log('PRECISION-DATE-FIXER: Initializing precision date correction system...');
    
    // Configuration précise
    const PRECISION_CONFIG = {
        interceptArrayMap: true,
        logInvalidDates: false, // Désactiver le logging pour réduire la verbosité
        fallbackToNow: true,
        preserveValidDates: true,
        debugMode: false
    };
    
    // Compteur pour les statistiques
    let stats = {
        totalMaps: 0,
        invalidDatesFound: 0,
        datesFixed: 0,
        errors: 0
    };
    
    // Fonction de validation précise des dates
    function validateDatePrecise(value) {
        // Cas null/undefined
        if (value === null || value === undefined) {
            if (PRECISION_CONFIG.debugMode) {
                console.warn('PRECISION-DATE-FIXER: null/undefined date detected');
            }
            return { valid: false, reason: 'null/undefined', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
        }
        
        // Si c'est déjà une Date
        if (value instanceof Date) {
            if (isNaN(value.getTime())) {
                if (PRECISION_CONFIG.debugMode) {
                    console.warn('PRECISION-DATE-FIXER: Invalid Date object detected', value);
                }
                return { valid: false, reason: 'invalid Date object', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
            }
            return { valid: true, date: value };
        }
        
        // Si c'est une chaîne vide
        if (typeof value === 'string' && value.trim() === '') {
            if (PRECISION_CONFIG.debugMode) {
                console.warn('PRECISION-DATE-FIXER: Empty string date detected');
            }
            return { valid: false, reason: 'empty string', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
        }
        
        // Si c'est une chaîne
        if (typeof value === 'string') {
            // Format ISO 8601
            if (value.includes('T') && (value.includes('Z') || value.includes('+'))) {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                    return { valid: true, date: date };
                }
            }
            
            // Format YYYY-MM-DD
            if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
                const date = new Date(value);
                if (!isNaN(date.getTime())) {
                    return { valid: true, date: date };
                }
            }
            
            // Format français DD/MM/YYYY (invalide pour JS)
            if (/^\d{2}\/\d{2}\/\d{4}$/.test(value)) {
                if (PRECISION_CONFIG.debugMode) {
                    console.warn('PRECISION-DATE-FIXER: French format detected (invalid for JS)', value);
                }
                const [day, month, year] = value.split('/');
                const isoDate = `${year}-${month}-${day}T00:00:00.000Z`;
                const date = new Date(isoDate);
                if (!isNaN(date.getTime())) {
                    return { valid: true, date: date, converted: true };
                }
                return { valid: false, reason: 'french format conversion failed', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
            }
            
            // Format DD-MM-YYYY (invalide pour JS)
            if (/^\d{2}-\d{2}-\d{4}$/.test(value)) {
                if (PRECISION_CONFIG.debugMode) {
                    console.warn('PRECISION-DATE-FIXER: DD-MM-YYYY format detected (invalid for JS)', value);
                }
                const [day, month, year] = value.split('-');
                const isoDate = `${year}-${month}-${day}T00:00:00.000Z`;
                const date = new Date(isoDate);
                if (!isNaN(date.getTime())) {
                    return { valid: true, date: date, converted: true };
                }
                return { valid: false, reason: 'DD-MM-YYYY format conversion failed', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
            }
            
            // Essayer parsing direct
            const date = new Date(value);
            if (!isNaN(date.getTime())) {
                return { valid: true, date: date };
            }
            
            // Chaîne invalide
            if (PRECISION_CONFIG.debugMode) {
                console.warn('PRECISION-DATE-FIXER: Invalid date string detected', value);
            }
            return { valid: false, reason: 'invalid string', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
        }
        
        // Si c'est un nombre
        if (typeof value === 'number') {
            const date = new Date(value);
            if (!isNaN(date.getTime())) {
                return { valid: true, date: date };
            }
            if (PRECISION_CONFIG.debugMode) {
                console.warn('PRECISION-DATE-FIXER: Invalid timestamp detected', value);
            }
            return { valid: false, reason: 'invalid timestamp', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
        }
        
        // Type non supporté
        if (PRECISION_CONFIG.debugMode) {
            console.warn('PRECISION-DATE-FIXER: Unsupported type detected', typeof value, value);
        }
        return { valid: false, reason: 'unsupported type', fixed: PRECISION_CONFIG.fallbackToNow ? new Date() : null };
    }
    
    // Intercepter Array.prototype.map avec précision
    function interceptArrayMapPrecise() {
        if (!PRECISION_CONFIG.interceptArrayMap) return;
        
        const originalMap = Array.prototype.map;
        
        Array.prototype.map = function(callback, thisArg) {
            stats.totalMaps++;
            
            // Vérifier si c'est un map qui pourrait contenir des dates
            const callbackString = callback.toString();
            const likelyDateMap = callbackString.includes('Date') || 
                                 callbackString.includes('date') || 
                                 callbackString.includes('createdAt') || 
                                 callbackString.includes('updatedAt') ||
                                 callbackString.includes('time');
            
            if (likelyDateMap || PRECISION_CONFIG.debugMode) {
                console.log('PRECISION-DATE-FIXER: Processing likely date map', {
                    arrayLength: this.length,
                    callbackPreview: callbackString.substring(0, 100)
                });
            }
            
            const newArray = originalMap.call(this, function(item, index, array) {
                try {
                    const result = callback.call(thisArg, item, index, array);
                    
                    // Vérifier si le résultat est une date invalide
                    if (result instanceof Date && isNaN(result.getTime())) {
                        stats.invalidDatesFound++;
                        stats.datesFixed++;
                        
                        if (PRECISION_CONFIG.logInvalidDates) {
                            console.error('PRECISION-DATE-FIXER: Invalid date found in map result', {
                                item: item,
                                index: index,
                                invalidResult: result,
                                fixedResult: new Date()
                            });
                        }
                        
                        return PRECISION_CONFIG.fallbackToNow ? new Date() : null;
                    }
                    
                    // Vérifier si le résultat contient des dates invalides (objets)
                    if (result && typeof result === 'object') {
                        const fixedResult = { ...result };
                        let hasInvalidDates = false;
                        
                        // Chercher les propriétés qui pourraient être des dates
                        Object.keys(fixedResult).forEach(key => {
                            const value = fixedResult[key];
                            const validation = validateDatePrecise(value);
                            
                            if (!validation.valid && value !== null && value !== undefined) {
                                hasInvalidDates = true;
                                stats.invalidDatesFound++;
                                stats.datesFixed++;
                                
                                if (PRECISION_CONFIG.logInvalidDates) {
                                    console.error('PRECISION-DATE-FIXER: Invalid date in object property', {
                                        key: key,
                                        value: value,
                                        reason: validation.reason,
                                        fixed: validation.fixed
                                    });
                                }
                                
                                fixedResult[key] = validation.fixed;
                            }
                        });
                        
                        if (hasInvalidDates) {
                            return fixedResult;
                        }
                    }
                    
                    return result;
                    
                } catch (error) {
                    stats.errors++;
                    
                    if (PRECISION_CONFIG.debugMode) {
                        console.error('PRECISION-DATE-FIXER: Error in map callback', {
                            error: error.message,
                            item: item,
                            index: index
                        });
                    }
                    
                    // Retourner l'item original en cas d'erreur
                    return item;
                }
            });
            
            return newArray;
        };
        
        console.log('PRECISION-DATE-FIXER: Array.map intercepted with precision');
    }
    
    // Créer le panneau de contrôle précis
    function createPrecisionDatePanel() {
        setTimeout(() => {
            if (document.getElementById('precision-date-fixer-panel')) return;
            
            const panel = document.createElement('div');
            panel.id = 'precision-date-fixer-panel';
            panel.style.cssText = `
                position: fixed;
                top: 500px;
                right: 20px;
                width: 400px;
                background: linear-gradient(135deg, #06b6d4 0%, #0891b2 100%);
                color: white;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                z-index: 99991;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                animation: slideInRight 0.5s ease-out;
            `;
            
            panel.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0; font-size: 16px; font-weight: 600;">🎯 Precision Date Fixer</h3>
                    <button onclick="this.parentElement.parentElement.remove()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 5px 10px; border-radius: 6px; cursor: pointer; font-size: 12px;">✕</button>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 15px;">
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Array.map</div>
                        <div style="font-size: 14px; font-weight: 600;">${PRECISION_CONFIG.interceptArrayMap ? '✅ PROTECTED' : '❌ NORMAL'}</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Debug Mode</div>
                        <div style="font-size: 14px; font-weight: 600;">${PRECISION_CONFIG.debugMode ? '✅ ACTIVE' : '❌ INACTIVE'}</div>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 5px;">Statistics:</div>
                    <div id="precision-stats" style="font-size: 11px; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 6px;">
                        <div>Total Maps: <span id="stat-total-maps">0</span></div>
                        <div>Invalid Dates Found: <span id="stat-invalid-dates">0</span></div>
                        <div>Dates Fixed: <span id="stat-dates-fixed">0</span></div>
                        <div>Errors: <span id="stat-errors">0</span></div>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                    <button onclick="testPrecisionFixer()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        🧪 Test Precision
                    </button>
                    <button onclick="resetStats()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        📊 Reset Stats
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr; gap: 10px;">
                    <button onclick="forcePrecisionFix()" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); border: none; color: white; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
                        🎯 FORCER CORRECTION PRÉCISE
                    </button>
                </div>
                
                <div id="precision-status" style="margin-top: 15px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 6px; font-size: 12px; display: none;">
                    <div id="precision-status-content"></div>
                </div>
            `;
            
            // Ajouter le CSS
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
            
            document.body.appendChild(panel);
            
            // Mettre à jour les statistiques
            setInterval(() => {
                updateStats();
            }, 1000);
            
            // Fonctions globales
            window.testPrecisionFixer = function() {
                showPrecisionStatus('🧪 Test de correction précise en cours...', 'info');
                
                // Tester avec des données problématiques
                const testData = [
                    { id: 1, createdAt: '2026-03-24T15:32:24.000Z' }, // ✅ Valid
                    { id: 2, createdAt: '25-03-2026' }, // ❌ French format
                    { id: 3, createdAt: null }, // ❌ Null
                    { id: 4, createdAt: undefined }, // ❌ Undefined
                    { id: 5, createdAt: '' }, // ❌ Empty string
                    { id: 6, createdAt: 'invalid-date' }, // ❌ Invalid string
                    { id: 7, createdAt: new Date('invalid') } // ❌ Invalid Date object
                ];
                
                try {
                    const results = testData.map(item => ({
                        ...item,
                        createdAt: new Date(item.createdAt)
                    }));
                    
                    setTimeout(() => {
                        const resultsText = results.map(r => 
                            `ID ${r.id}: ${r.createdAt instanceof Date && !isNaN(r.createdAt.getTime()) ? '✅' : '❌'} ${r.createdAt instanceof Date ? r.createdAt.toISOString() : r.createdAt}`
                        ).join('\n');
                        
                        showPrecisionStatus(`✅ Test précis terminé!\n\nRésultats:\n${resultsText}\n\nStatistiques:\n${JSON.stringify(stats, null, 2)}`, 'success');
                    }, 1000);
                    
                } catch (error) {
                    showPrecisionStatus(`❌ Erreur dans le test: ${error.message}`, 'error');
                }
            };
            
            window.resetStats = function() {
                stats = {
                    totalMaps: 0,
                    invalidDatesFound: 0,
                    datesFixed: 0,
                    errors: 0
                };
                updateStats();
                showPrecisionStatus('📊 Statistiques réinitialisées', 'info');
            };
            
            window.forcePrecisionFix = function() {
                showPrecisionStatus('🎯 Force correction précise...', 'info');
                
                setTimeout(() => {
                    // Réinitialiser et réintercepter
                    interceptArrayMapPrecise();
                    
                    showPrecisionStatus('🎯 Correction précise forcée!\n\n✅ Array.map protégé\n✅ Validation précise activée\n✅ Debug mode activé\n✅ Fallback garanti\n\n🔄 Actualisation dans 2 secondes...', 'success');
                    
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                }, 1500);
            };
            
            console.log('PRECISION-DATE-FIXER: Precision date panel created');
        }, 9000);
    }
    
    // Mettre à jour les statistiques
    function updateStats() {
        const totalMapsEl = document.getElementById('stat-total-maps');
        const invalidDatesEl = document.getElementById('stat-invalid-dates');
        const datesFixedEl = document.getElementById('stat-dates-fixed');
        const errorsEl = document.getElementById('stat-errors');
        
        if (totalMapsEl) totalMapsEl.textContent = stats.totalMaps;
        if (invalidDatesEl) invalidDatesEl.textContent = stats.invalidDatesFound;
        if (datesFixedEl) datesFixedEl.textContent = stats.datesFixed;
        if (errorsEl) errorsEl.textContent = stats.errors;
    }
    
    // Afficher le statut
    function showPrecisionStatus(message, type = 'info') {
        const statusDiv = document.getElementById('precision-status');
        const contentDiv = document.getElementById('precision-status-content');
        
        if (statusDiv && contentDiv) {
            statusDiv.style.display = 'block';
            contentDiv.innerHTML = `<div style="white-space: pre-line;">${message}</div>`;
            
            const colors = {
                success: 'rgba(16, 185, 129, 0.3)',
                error: 'rgba(239, 68, 68, 0.3)',
                info: 'rgba(59, 130, 246, 0.3)',
                warning: 'rgba(245, 158, 11, 0.3)'
            };
            statusDiv.style.background = colors[type] || colors.info;
        }
    }
    
    // Initialisation
    function initialize() {
        console.log('PRECISION-DATE-FIXER: Starting precision date fixer initialization...');
        
        // Intercepter Array.map avec précision
        interceptArrayMapPrecise();
        
        // Créer le panneau de contrôle
        createPrecisionDatePanel();
        
        console.log('PRECISION-DATE-FIXER: Precision date fixer initialization complete');
    }
    
    // Démarrer l'initialisation
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
    
})();
