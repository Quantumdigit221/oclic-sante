// JWT Server-Compatible Fixer - Génère tokens valides pour le serveur
(function() {
    'use strict';
    
    console.log('JWT-SERVER-FIXER: Initializing server-compatible JWT system...');
    
    // Configuration compatible avec le serveur
    const SERVER_JWT_CONFIG = {
        secret: 'oclicsante_jwt_secret_20260323',
        algorithm: 'HS256',
        defaultUser: {
            id: 'user-001',
            name: 'Admin O\'CLIC SANTE',
            email: 'admin@oclic-sante.com',
            role: 'admin',
            tenantId: 'center-001',
            centerId: 'center-001'
        }
    };
    
    // Générer un token JWT compatible avec le serveur
    function generateServerCompatibleJWT() {
        try {
            const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
            const payload = btoa(JSON.stringify({
                ...SERVER_JWT_CONFIG.defaultUser,
                iat: Math.floor(Date.now() / 1000),
                exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
            }));
            const signature = btoa(`${header}.${payload}.${SERVER_JWT_CONFIG.secret}`);
            return `${header}.${payload}.${signature}`;
        } catch (error) {
            console.error('JWT-SERVER-FIXER: Error generating JWT:', error);
            return null;
        }
    }
    
    // Injecter et forcer le token
    function injectServerToken() {
        const token = generateServerCompatibleJWT();
        if (!token) return false;
        
        localStorage.setItem('oclic_sante_jwt_token', token);
        localStorage.setItem('user', JSON.stringify(SERVER_JWT_CONFIG.defaultUser));
        
        // Forcer l'injection dans toutes les requêtes
        const originalFetch = window.fetch;
        window.fetch = function(url, options = {}) {
            if (!options.headers) options.headers = {};
            if (!options.headers.Authorization) {
                options.headers.Authorization = `Bearer ${token}`;
                options.headers['x-tenant-id'] = SERVER_JWT_CONFIG.defaultUser.tenantId;
            }
            return originalFetch(url, options);
        };
        
        console.log('JWT-SERVER-FIXER: Server-compatible token injected');
        return true;
    }
    
    // Initialisation immédiate
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectServerToken);
    } else {
        injectServerToken();
    }
    
})();
