﻿// Speech-to-text helper for consultation fields (React-compatible)
(function () {
  'use strict';

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn('[Speech] API not available in this browser.');
    return;
  }

  const FIELD_TAG = 'data-speech-enabled';
  const fieldModes = new WeakMap(); // element -> "replace" | "append"
  let activeSession = null;

  function normalize(str) {
    return String(str || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  }

  function setReactInputValue(element, value) {
    const descriptor = Object.getOwnPropertyDescriptor(element, 'value');
    const prototype = Object.getPrototypeOf(element);
    const prototypeDescriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
    const setter = descriptor && descriptor.set ? descriptor.set : (prototypeDescriptor && prototypeDescriptor.set);

    if (setter) setter.call(element, value);
    else element.value = value;

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function appendTranscript(element, transcript) {
    const mode = fieldModes.get(element) || 'append';
    const clean = transcript.trim();
    if (!clean) return;

    if (mode === 'replace') {
      setReactInputValue(element, clean);
      return;
    }

    const current = String(element.value || '');
    const sep = current && !/\s$/.test(current) ? ' ' : '';
    setReactInputValue(element, current + sep + clean);
  }

  function stopActiveSession() {
    if (!activeSession) return;
    try {
      activeSession.recognition.stop();
    } catch (_) {
      // no-op
    }
    activeSession = null;
  }

  function updateButtonState(button, listening) {
    button.textContent = listening ? 'Stop Dictee' : 'Dictee';
    button.style.background = listening ? '#ef4444' : '#e2e8f0';
    button.style.color = listening ? '#ffffff' : '#0f172a';
  }

  function startDictation(target, button) {
    if (activeSession && activeSession.target === target) {
      stopActiveSession();
      updateButtonState(button, false);
      return;
    }

    if (activeSession) {
      updateButtonState(activeSession.button, false);
      stopActiveSession();
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.interimResults = false;
    recognition.continuous = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = function (event) {
      let transcript = '';
      for (let i = event.resultIndex; i < event.results.length; i += 1) {
        if (event.results[i].isFinal) transcript += event.results[i][0].transcript + ' ';
      }
      appendTranscript(target, transcript);
    };

    recognition.onerror = function (event) {
      console.warn('[Speech] Error:', event.error);
      if (activeSession && activeSession.button === button) {
        updateButtonState(button, false);
        activeSession = null;
      }
    };

    recognition.onend = function () {
      if (activeSession && activeSession.button === button) {
        updateButtonState(button, false);
        activeSession = null;
      }
    };

    activeSession = { recognition, target, button };
    updateButtonState(button, true);
    recognition.start();
  }

  function createMicButton(target) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = 'Dictee';
    button.style.marginLeft = '8px';
    button.style.padding = '2px 8px';
    button.style.fontSize = '11px';
    button.style.border = '1px solid #cbd5e1';
    button.style.borderRadius = '999px';
    button.style.cursor = 'pointer';
    button.style.background = '#e2e8f0';
    button.style.color = '#0f172a';
    button.title = 'Demarrer la dictee vocale';
    button.addEventListener('click', function (ev) {
      ev.preventDefault();
      startDictation(target, button);
    });
    return button;
  }

  function findLabelForField(field) {
    const parent = field.parentElement;
    if (!parent) return null;
    const directLabel = parent.querySelector('label');
    if (directLabel) return directLabel;
    const prev = field.previousElementSibling;
    if (prev && prev.tagName === 'LABEL') return prev;
    return null;
  }

  function classifyField(field) {
    const placeholder = normalize(field.getAttribute('placeholder'));
    const label = normalize(findLabelForField(field)?.textContent || '');

    const text = placeholder + ' ' + label;

    // Vitals: replace mode
    if (text.includes('temperature') || placeholder.includes('37')) return 'replace';
    if (text.includes('poids') || placeholder.includes('kg')) return 'replace';
    if (text.includes('tension') || placeholder.includes('120/80')) return 'replace';
    if (text.includes('pouls') || placeholder.includes('bpm')) return 'replace';

    // Clinical text: append mode
    if (text.includes('symptomes') || text.includes('motif de consultation')) return 'append';
    if (text.includes('diagnostic provisoire') || text === 'diagnostic') return 'append';
    if (text.includes('notes cliniques') || text.includes('observations supplementaires')) return 'append';

    return null;
  }

  function enableField(field) {
    if (!field || field.getAttribute(FIELD_TAG) === '1') return;
    const mode = classifyField(field);
    if (!mode) return;

    fieldModes.set(field, mode);
    field.setAttribute(FIELD_TAG, '1');

    const label = findLabelForField(field);
    if (!label) return;

    const btnKey = field.name || field.placeholder || mode;
    if (label.querySelector('[' + FIELD_TAG + '-btn-for="' + btnKey + '"]')) return;

    const button = createMicButton(field);
    button.setAttribute(FIELD_TAG + '-btn-for', btnKey);
    label.appendChild(button);
  }

  function scanAndAttach() {
    const fields = document.querySelectorAll('input[type="text"], textarea');
    fields.forEach(enableField);
  }

  const observer = new MutationObserver(scanAndAttach);
  document.addEventListener('DOMContentLoaded', function () {
    scanAndAttach();
    observer.observe(document.body, { childList: true, subtree: true });
    console.log('[Speech] Consultation voice dictation enabled.');
  });
})();
