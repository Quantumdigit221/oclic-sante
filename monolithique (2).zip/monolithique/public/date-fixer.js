// Correcteur de dates invalides - Fix "Invalid time value" errors
(function() {
    'use strict';
    
    console.log('DATE-FIXER: Initializing date validation system...');
    
    // Fonction pour valider et corriger les dates
    function fixInvalidDate(dateValue) {
        if (!dateValue) return new Date();
        
        try {
            const date = new Date(dateValue);
            if (isNaN(date.getTime())) {
                console.warn('DATE-FIXER: Invalid date detected:', dateValue);
                return new Date();
            }
            return date;
        } catch (error) {
            console.warn('DATE-FIXER: Date parsing error:', error);
            return new Date();
        }
    }
    
    // Intercepter les appels à new Date
    const originalDate = window.Date;
    window.Date = function(...args) {
        if (args.length === 1 && typeof args[0] === 'string') {
            const fixedDate = fixInvalidDate(args[0]);
            return originalDate.call(this, fixedDate);
        }
        return originalDate.apply(this, args);
    };
    
    // Copier les méthodes statiques
    Object.setPrototypeOf(window.Date, originalDate);
    Object.getOwnPropertyNames(originalDate).forEach(name => {
        if (name !== 'prototype' && !(name in window.Date)) {
            window.Date[name] = originalDate[name];
        }
    });
    
    console.log('DATE-FIXER: Date validation system active');
})();
