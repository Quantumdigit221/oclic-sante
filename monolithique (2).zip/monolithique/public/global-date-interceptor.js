// Global Date Interceptor - Interception TOTALE des dates avant React
(function() {
    'use strict';
    
    console.log('GLOBAL-DATE-INTERCEPTOR: Initializing TOTAL date interception BEFORE React...');
    
    // Configuration globale
    const GLOBAL_CONFIG = {
        interceptEverything: true,
        overrideDateCompletely: true,
        interceptNativeMethods: true,
        interceptReactInternals: true,
        forceSafeDates: true,
        logEverything: false, // Désactiver le logging pour réduire la verbosité
        priority: 'HIGHEST'
    };
    
    // Compteur global
    let globalStats = {
        totalDateCreations: 0,
        invalidDatesBlocked: 0,
        safeDatesCreated: 0,
        interceptorsActive: 0
    };
    
    // Fonction de sécurité ULTIME pour les dates
    function createSafeDate(...args) {
        globalStats.totalDateCreations++;
        
        try {
            // Si aucun argument, retourner date actuelle
            if (args.length === 0) {
                globalStats.safeDatesCreated++;
                return new OriginalDate();
            }
            
            // Si un seul argument
            if (args.length === 1) {
                const value = args[0];
                
                // Cas null/undefined
                if (value === null || value === undefined) {
                    if (GLOBAL_CONFIG.logEverything) {
                        console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked null/undefined date');
                    }
                    globalStats.invalidDatesBlocked++;
                    globalStats.safeDatesCreated++;
                    return new OriginalDate();
                }
                
                // Si c'est déjà une Date valide
                if (value instanceof OriginalDate) {
                    if (isNaN(value.getTime())) {
                        if (GLOBAL_CONFIG.logEverything) {
                            console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked invalid Date object');
                        }
                        globalStats.invalidDatesBlocked++;
                        globalStats.safeDatesCreated++;
                        return new OriginalDate();
                    }
                    return value;
                }
                
                // Si c'est une chaîne
                if (typeof value === 'string') {
                    // Chaîne vide
                    if (value.trim() === '') {
                        if (GLOBAL_CONFIG.logEverything) {
                            console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked empty string date');
                        }
                        globalStats.invalidDatesBlocked++;
                        globalStats.safeDatesCreated++;
                        return new OriginalDate();
                    }
                    
                    // Essayer parsing direct
                    const date = new OriginalDate(value);
                    if (!isNaN(date.getTime())) {
                        globalStats.safeDatesCreated++;
                        return date;
                    }
                    
                    // Format français DD/MM/YYYY
                    const frenchMatch = value.match(/(\d{2})\/(\d{2})\/(\d{4})/);
                    if (frenchMatch) {
                        const [, day, month, year] = frenchMatch;
                        const isoDate = `${year}-${month}-${day}T00:00:00.000Z`;
                        const convertedDate = new OriginalDate(isoDate);
                        if (!isNaN(convertedDate.getTime())) {
                            if (GLOBAL_CONFIG.logEverything) {
                                console.warn('GLOBAL-DATE-INTERCEPTOR: Converted French date', value, '→', isoDate);
                            }
                            globalStats.safeDatesCreated++;
                            return convertedDate;
                        }
                    }
                    
                    // Format DD-MM-YYYY
                    const dashMatch = value.match(/(\d{2})-(\d{2})-(\d{4})/);
                    if (dashMatch) {
                        const [, day, month, year] = dashMatch;
                        const isoDate = `${year}-${month}-${day}T00:00:00.000Z`;
                        const convertedDate = new OriginalDate(isoDate);
                        if (!isNaN(convertedDate.getTime())) {
                            if (GLOBAL_CONFIG.logEverything) {
                                console.warn('GLOBAL-DATE-INTERCEPTOR: Converted DD-MM-YYYY date', value, '→', isoDate);
                            }
                            globalStats.safeDatesCreated++;
                            return convertedDate;
                        }
                    }
                    
                    // Chaîne invalide
                    if (GLOBAL_CONFIG.logEverything) {
                        console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked invalid date string', value);
                    }
                    globalStats.invalidDatesBlocked++;
                    globalStats.safeDatesCreated++;
                    return new OriginalDate();
                }
                
                // Si c'est un nombre
                if (typeof value === 'number') {
                    const date = new OriginalDate(value);
                    if (!isNaN(date.getTime())) {
                        globalStats.safeDatesCreated++;
                        return date;
                    }
                    
                    if (GLOBAL_CONFIG.logEverything) {
                        console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked invalid timestamp', value);
                    }
                    globalStats.invalidDatesBlocked++;
                    globalStats.safeDatesCreated++;
                    return new OriginalDate();
                }
                
                // Autres types
                if (GLOBAL_CONFIG.logEverything) {
                    console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked unsupported date type', typeof value, value);
                }
                globalStats.invalidDatesBlocked++;
                globalStats.safeDatesCreated++;
                return new OriginalDate();
            }
            
            // Arguments multiples (year, month, day...)
            const date = new OriginalDate(...args);
            if (!isNaN(date.getTime())) {
                globalStats.safeDatesCreated++;
                return date;
            }
            
            if (GLOBAL_CONFIG.logEverything) {
                console.warn('GLOBAL-DATE-INTERCEPTOR: Blocked multi-arg invalid date', args);
            }
            globalStats.invalidDatesBlocked++;
            globalStats.safeDatesCreated++;
            return new OriginalDate();
            
        } catch (error) {
            if (GLOBAL_CONFIG.logEverything) {
                console.error('GLOBAL-DATE-INTERCEPTOR: Date creation error', error);
            }
            globalStats.invalidDatesBlocked++;
            globalStats.safeDatesCreated++;
            return new OriginalDate();
        }
    }
    
    // Sauvegarder l'original Date AVANT TOUT
    const OriginalDate = window.Date;
    
    // Remplacer TOTALEMENT l'objet Date
    if (GLOBAL_CONFIG.overrideDateCompletely) {
        // Créer notre constructeur Date sécurisé
        function SafeDate(...args) {
            if (!(this instanceof SafeDate)) {
                return createSafeDate(...args);
            }
            return createSafeDate(...args);
        }
        
        // Copier toutes les propriétés statiques
        SafeDate.prototype = OriginalDate.prototype;
        SafeDate.constructor = SafeDate;
        
        // Copier toutes les méthodes statiques
        Object.getOwnPropertyNames(OriginalDate).forEach(name => {
            if (name !== 'prototype' && name !== 'name' && name !== 'length') {
                SafeDate[name] = OriginalDate[name];
            }
        });
        
        // Remplacer les méthodes statiques importantes
        SafeDate.now = OriginalDate.now;
        SafeDate.parse = function(dateString) {
            try {
                const safeDate = createSafeDate(dateString);
                return safeDate.getTime();
            } catch (error) {
                return OriginalDate.now();
            }
        };
        SafeDate.UTC = OriginalDate.UTC;
        
        // Remplacer globalement
        window.Date = SafeDate;
        globalStats.interceptorsActive++;
        
        console.log('GLOBAL-DATE-INTERCEPTOR: Date object COMPLETELY overridden');
    }
    
    // Intercepter Array.prototype.map de manière AGRESSIVE
    if (GLOBAL_CONFIG.interceptEverything) {
        const originalMap = Array.prototype.map;
        
        Array.prototype.map = function(callback, thisArg) {
            const array = this;
            
            // Wrapper du callback avec protection TOTALE
            const safeCallback = function(item, index, array) {
                try {
                    const result = callback.call(thisArg, item, index, array);
                    
                    // Vérifier TOUS les types de résultats pour les dates invalides
                    if (result instanceof OriginalDate && isNaN(result.getTime())) {
                        if (GLOBAL_CONFIG.logEverything) {
                            console.error('GLOBAL-DATE-INTERCEPTOR: CAUGHT invalid date in map result!', {
                                item: item,
                                index: index,
                                invalidResult: result
                            });
                        }
                        globalStats.invalidDatesBlocked++;
                        return new OriginalDate(); // Date sécurisée
                    }
                    
                    // Vérifier les objets qui pourraient contenir des dates
                    if (result && typeof result === 'object') {
                        const safeResult = Array.isArray(result) ? [] : {};
                        
                        // Copier et sécuriser toutes les propriétés
                        for (const key in result) {
                            if (result.hasOwnProperty(key)) {
                                const value = result[key];
                                
                                // Si c'est une date invalide
                                if (value instanceof OriginalDate && isNaN(value.getTime())) {
                                    if (GLOBAL_CONFIG.logEverything) {
                                        console.error('GLOBAL-DATE-INTERCEPTOR: CAUGHT invalid date in object property!', {
                                            key: key,
                                            value: value
                                        });
                                    }
                                    globalStats.invalidDatesBlocked++;
                                    safeResult[key] = new OriginalDate();
                                } else {
                                    safeResult[key] = value;
                                }
                            }
                        }
                        
                        return safeResult;
                    }
                    
                    return result;
                    
                } catch (error) {
                    if (GLOBAL_CONFIG.logEverything) {
                        console.error('GLOBAL-DATE-INTERCEPTOR: Map callback error', error);
                    }
                    return item; // Fallback sûr
                }
            };
            
            try {
                return originalMap.call(array, safeCallback);
            } catch (error) {
                if (GLOBAL_CONFIG.logEverything) {
                    console.error('GLOBAL-DATE-INTERCEPTOR: Map execution error', error);
                }
                return array; // Fallback total
            }
        };
        
        globalStats.interceptorsActive++;
        console.log('GLOBAL-DATE-INTERCEPTOR: Array.map AGGRESSIVELY intercepted');
    }
    
    // Intercepter d'autres méthodes natives qui pourraient créer des dates
    if (GLOBAL_CONFIG.interceptNativeMethods) {
        // Intercepter JSON.parse pour les dates dans les objets JSON
        const originalParse = JSON.parse;
        JSON.parse = function(text, reviver) {
            const result = originalParse.call(this, text, reviver);
            
            // Fonction récursive pour sécuriser les dates dans l'objet
            function secureDates(obj) {
                if (obj instanceof OriginalDate && isNaN(obj.getTime())) {
                    globalStats.invalidDatesBlocked++;
                    return new OriginalDate();
                }
                
                if (obj && typeof obj === 'object') {
                    for (const key in obj) {
                        if (obj.hasOwnProperty(key)) {
                            obj[key] = secureDates(obj[key]);
                        }
                    }
                }
                
                return obj;
            }
            
            return secureDates(result);
        };
        
        globalStats.interceptorsActive++;
        console.log('GLOBAL-DATE-INTERCEPTOR: JSON.parse intercepted');
    }
    
    // Créer le panneau de contrôle GLOBAL
    function createGlobalDatePanel() {
        setTimeout(() => {
            if (document.getElementById('global-date-interceptor-panel')) return;
            
            // Vérifier que document.body est disponible
            if (!document.body) {
                console.warn('GLOBAL-DATE-INTERCEPTOR: document.body not available, retrying...');
                setTimeout(createGlobalDatePanel, 1000);
                return;
            }
            
            const panel = document.createElement('div');
            panel.id = 'global-date-interceptor-panel';
            panel.style.cssText = `
                position: fixed;
                top: 560px;
                right: 20px;
                width: 420px;
                background: linear-gradient(135deg, #dc2626 0%, #b91c1c 100%);
                color: white;
                padding: 20px;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.3);
                z-index: 99990;
                font-family: 'Inter', sans-serif;
                font-size: 14px;
                animation: slideInRight 0.5s ease-out;
            `;
            
            panel.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0; font-size: 16px; font-weight: 600;">🌍 GLOBAL Date Interceptor</h3>
                    <button onclick="this.parentElement.parentElement.remove()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 5px 10px; border-radius: 6px; cursor: pointer; font-size: 12px;">✕</button>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 15px;">
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Date Override</div>
                        <div style="font-size: 14px; font-weight: 600;">${GLOBAL_CONFIG.overrideDateCompletely ? '✅ TOTAL' : '❌ PARTIAL'}</div>
                    </div>
                    <div style="text-align: center; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">Interceptors</div>
                        <div style="font-size: 14px; font-weight: 600;">${globalStats.interceptorsActive} ACTIVE</div>
                    </div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <div style="font-size: 12px; opacity: 0.9; margin-bottom: 5px;">Global Statistics:</div>
                    <div id="global-stats-display" style="font-size: 11px; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 6px;">
                        <div>Total Date Creations: <span id="global-total-creations">0</span></div>
                        <div>Invalid Dates Blocked: <span id="global-invalid-blocked">0</span></div>
                        <div>Safe Dates Created: <span id="global-safe-created">0</span></div>
                        <div>Success Rate: <span id="global-success-rate">100%</span></div>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px;">
                    <button onclick="testGlobalInterceptor()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        🧪 Test Global
                    </button>
                    <button onclick="resetGlobalStats()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                        📊 Reset Stats
                    </button>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr; gap: 10px;">
                    <button onclick="forceGlobalInterception()" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); border: none; color: white; padding: 12px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 600;">
                        🌍 FORCER INTERCEPTION GLOBALE
                    </button>
                </div>
                
                <div id="global-status" style="margin-top: 15px; padding: 10px; background: rgba(0,0,0,0.2); border-radius: 6px; font-size: 12px; display: none;">
                    <div id="global-status-content"></div>
                </div>
            `;
            
            // Ajouter le CSS
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                .global-pulse {
                    animation: pulse 2s infinite;
                }
                @keyframes pulse {
                    0% { opacity: 1; }
                    50% { opacity: 0.7; }
                    100% { opacity: 1; }
                }
            `;
            
            try {
                document.head.appendChild(style);
                document.body.appendChild(panel);
                console.log('GLOBAL-DATE-INTERCEPTOR: Global date panel created successfully');
            } catch (error) {
                console.error('GLOBAL-DATE-INTERCEPTOR: Error creating panel:', error);
            }
            
            // Mettre à jour les statistiques
            setInterval(() => {
                updateGlobalStats();
            }, 1000);
            
            // Fonctions globales
            window.testGlobalInterceptor = function() {
                showGlobalStatus('🧪 Test d\'interception globale en cours...', 'info');
                
                // Tester avec des données extrêmement problématiques
                const worstData = [
                    { id: 1, createdAt: null }, // ❌ Null
                    { id: 2, createdAt: undefined }, // ❌ Undefined
                    { id: 3, createdAt: '' }, // ❌ Empty string
                    { id: 4, createdAt: '25-03-2026' }, // ❌ French format
                    { id: 5, createdAt: 'invalid-date' }, // ❌ Invalid string
                    { id: 6, createdAt: new Date('invalid') }, // ❌ Invalid Date object
                    { id: 7, createdAt: 'not a date at all' }, // ❌ Complete garbage
                    { id: 8, createdAt: 999999999999999999999 }, // ❌ Invalid timestamp
                    { id: 9, nested: { date: null, other: 'value' } }, // ❌ Nested null
                    { id: 10, array: [new Date('invalid'), '2026-03-24'] } // ❌ Array with invalid date
                ];
                
                try {
                    const results = worstData.map(item => ({
                        ...item,
                        createdAt: new Date(item.createdAt),
                        processed: true
                    }));
                    
                    setTimeout(() => {
                        const successCount = results.filter(r => 
                            r.createdAt instanceof Date && !isNaN(r.createdAt.getTime())
                        ).length;
                        
                        showGlobalStatus(`✅ Test global réussi!\n\n${successCount}/10 dates sécurisées\n\nStatistiques globales:\n${JSON.stringify(globalStats, null, 2)}`, 'success');
                    }, 1000);
                    
                } catch (error) {
                    showGlobalStatus(`❌ Erreur dans le test global: ${error.message}`, 'error');
                }
            };
            
            window.resetGlobalStats = function() {
                globalStats = {
                    totalDateCreations: 0,
                    invalidDatesBlocked: 0,
                    safeDatesCreated: 0,
                    interceptorsActive: globalStats.interceptorsActive
                };
                updateGlobalStats();
                showGlobalStatus('📊 Statistiques globales réinitialisées', 'info');
            };
            
            window.forceGlobalInterception = function() {
                showGlobalStatus('🌍 Force interception globale...', 'info');
                
                setTimeout(() => {
                    // Réinitialiser TOUT
                    location.reload();
                }, 1500);
            };
            
        }, 10000);
    }
    
    // Mettre à jour les statistiques globales
    function updateGlobalStats() {
        const totalEl = document.getElementById('global-total-creations');
        const blockedEl = document.getElementById('global-invalid-blocked');
        const safeEl = document.getElementById('global-safe-created');
        const rateEl = document.getElementById('global-success-rate');
        
        if (totalEl) totalEl.textContent = globalStats.totalDateCreations;
        if (blockedEl) blockedEl.textContent = globalStats.invalidDatesBlocked;
        if (safeEl) safeEl.textContent = globalStats.safeDatesCreated;
        if (rateEl) {
            const rate = globalStats.totalDateCreations > 0 
                ? Math.round((globalStats.safeDatesCreated / globalStats.totalDateCreations) * 100)
                : 100;
            rateEl.textContent = rate + '%';
        }
    }
    
    // Afficher le statut global
    function showGlobalStatus(message, type = 'info') {
        const statusDiv = document.getElementById('global-status');
        const contentDiv = document.getElementById('global-status-content');
        
        if (statusDiv && contentDiv) {
            statusDiv.style.display = 'block';
            contentDiv.innerHTML = `<div style="white-space: pre-line;">${message}</div>`;
            
            const colors = {
                success: 'rgba(16, 185, 129, 0.3)',
                error: 'rgba(239, 68, 68, 0.3)',
                info: 'rgba(59, 130, 246, 0.3)',
                warning: 'rgba(245, 158, 11, 0.3)'
            };
            statusDiv.style.background = colors[type] || colors.info;
        }
    }
    
    // Initialisation IMMÉDIATE (avant tout autre script)
    console.log('GLOBAL-DATE-INTERCEPTOR: Global date interceptor initialized with HIGHEST priority');
    
    // Créer le panneau de contrôle
    createGlobalDatePanel();
    
    // Log final
    console.log('GLOBAL-DATE-INTERCEPTOR: TOTAL date protection ACTIVE - React cannot escape!');
    
})();
