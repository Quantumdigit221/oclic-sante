// =============================================
// O'CLIC SANTE - Connexion Base de Données (RESCUE VERSION)
// =============================================

import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

function isPlaceholder(v = '') {
  const s = String(v || '').trim();
  if (!s) return true;
  return (
    s.startsWith('REPLACE_WITH_') ||
    s.includes('your_') ||
    s.includes('votre_') ||
    s === 'changeme'
  );
}

function buildDbConfigFromEnv() {
  const fromUrl = {};
  const rawUrl = process.env.DATABASE_URL || process.env.MYSQL_URL || '';
  if (rawUrl) {
    try {
      const u = new URL(rawUrl);
      fromUrl.host = u.hostname;
      fromUrl.port = u.port ? Number(u.port) : undefined;
      fromUrl.user = decodeURIComponent(u.username || '');
      fromUrl.password = decodeURIComponent(u.password || '');
      fromUrl.database = (u.pathname || '').replace(/^\//, '');
    } catch {
      // Ignore DATABASE_URL parsing errors and fallback to DB_* vars
    }
  }

  return {
    host: process.env.DB_HOST || fromUrl.host || '127.0.0.1',
    port: Number(process.env.DB_PORT || fromUrl.port || 3306),
    user: process.env.DB_USER || fromUrl.user || '',
    password: process.env.DB_PASSWORD || fromUrl.password || '',
    database: process.env.DB_NAME || fromUrl.database || '',
    charset: 'utf8mb4',
    timezone: '+00:00',
    acquireTimeout: 10000,
    connectionLimit: 5,
    waitForConnections: true,
    queueLimit: 10,
    enableKeepAlive: true,
    ssl: (process.env.DB_SSL === 'true') ? { rejectUnauthorized: false } : undefined
  };
}

const dbConfig = buildDbConfigFromEnv();

function validateDbConfig(config) {
  const bad =
    isPlaceholder(config.host) ||
    isPlaceholder(config.user) ||
    isPlaceholder(config.password) ||
    isPlaceholder(config.database);
  if (bad) {
    return "Configuration DB invalide: renseigner DB_HOST, DB_USER, DB_PASSWORD, DB_NAME (ou DATABASE_URL) avec des valeurs réelles.";
  }
  return null;
}

const mysqlConfig = {
  host: dbConfig.host,
  port: dbConfig.port,
  user: dbConfig.user,
  password: dbConfig.password,
  database: dbConfig.database,
  charset: 'utf8mb4',
  timezone: '+00:00',
  connectTimeout: 15000,      // 15s max pour établir la connexion
  acquireTimeout: 15000,      // 15s pour obtenir une connexion du pool
  timeout: 20000,             // 20s max par requête SQL
  connectionLimit: 5,         // réduit pour Hostinger shared hosting
  waitForConnections: true,
  queueLimit: 10,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  ssl: dbConfig.ssl
};

let pool;
let dbErrorLog = null;

const __filename_db = fileURLToPath(import.meta.url);
const __dirname_db = path.dirname(__filename_db);
const logFile = path.join(__dirname_db, '../server-err.log');

function logToFile(msg) {
  try {
    const time = new Date().toISOString();
    fs.appendFileSync(logFile, `[${time}] ${msg}\n`);
    console.log(`[LOG] ${msg}`);
  } catch (e) { }
}

export function getDbErrorLog() {
  return dbErrorLog;
}

export async function query(sql, params = []) {
  try {
    if (!pool) throw new Error('Base de données non initialisée');
    const cleanParams = Array.isArray(params) ? params.map(p => p === undefined ? null : p) : [];
    // Timeout par requête : évite de bloquer le serveur si Hostinger est lent
    const QUERY_TIMEOUT_MS = 18000;
    const queryPromise = pool.query(sql, cleanParams);
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`SQL timeout après ${QUERY_TIMEOUT_MS}ms: ${sql.slice(0, 80)}`)), QUERY_TIMEOUT_MS)
    );
    const [rows] = await Promise.race([queryPromise, timeoutPromise]);
    return Array.isArray(rows) ? rows : (rows ? [rows] : []);
  } catch (error) {
    console.error('Erreur SQL:', error.message);
    throw error;
  }
}

export async function transaction(callback) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const result = await callback(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function initializeDatabase() {
  logToFile(`INIT: Connexion sur ${dbConfig.host}:${dbConfig.port}...`);
  try {
    const configError = validateDbConfig(dbConfig);
    if (configError) {
      dbErrorLog = configError;
      logToFile(`ECHEC CONFIG DB: ${configError}`);
      return false;
    }

    dbErrorLog = null;
    // CRITIQUE : mysql2/promise utilise .createPool() directement sur l'objet importé
    pool = mysql.createPool(mysqlConfig);


    // Test simple
    await pool.query('SELECT 1');
    logToFile(`SUCCÈS: DB Connectée.`);

    // Tables Vitales
    await query(`CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(255) PRIMARY KEY, 
      name VARCHAR(255), 
      email VARCHAR(255) UNIQUE, 
      password VARCHAR(255), 
      role VARCHAR(50) DEFAULT 'USER',
      specialty VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS tickets (
      id VARCHAR(255) PRIMARY KEY, 
      ticket_number VARCHAR(255) UNIQUE, 
      patient_id VARCHAR(255),
      service_id VARCHAR(255),
      doctor_id VARCHAR(255),
      patient_name VARCHAR(255), 
      patient_age INT,
      patient_gender VARCHAR(10),
      patient_phone VARCHAR(50),
      patient_address TEXT,
      service_name VARCHAR(255), 
      amount DECIMAL(10,2) DEFAULT 0.00, 
      payment_method VARCHAR(50) DEFAULT 'CASH',
      notes TEXT,
      status VARCHAR(50) DEFAULT 'WAITING', 
      center_id VARCHAR(255) DEFAULT 'center-001', 
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS ticket_services (
      id VARCHAR(255) PRIMARY KEY, 
      ticket_id VARCHAR(255), 
      service_id VARCHAR(255),
      service_name VARCHAR(255), 
      price DECIMAL(10,2), 
      quantity INT DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS patients (
      id VARCHAR(255) PRIMARY KEY, 
      name VARCHAR(255), 
      firstName VARCHAR(255),
      lastName VARCHAR(255),
      dateOfBirth DATE,
      age INT,
      gender VARCHAR(10),
      phone VARCHAR(20),
      address TEXT,
      center_id VARCHAR(255) DEFAULT 'center-001', 
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS services (
      id VARCHAR(255) PRIMARY KEY, 
      name VARCHAR(255), 
      description TEXT,
      category VARCHAR(255) DEFAULT 'Consultation',
      price DECIMAL(10,2), 
      durationMinutes INT DEFAULT 30,
      color VARCHAR(50),
      centerId VARCHAR(255) DEFAULT 'center-001',
      isActive TINYINT(1) DEFAULT 1,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS medicines (
      id VARCHAR(255) PRIMARY KEY, 
      name VARCHAR(255), 
      generic_name VARCHAR(255),
      stock_quantity INT DEFAULT 0, 
      min_stock_alert INT DEFAULT 10,
      price DECIMAL(10,2), 
      category VARCHAR(255) DEFAULT 'Général',
      center_id VARCHAR(255) DEFAULT 'center-001',
      active TINYINT(1) DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS settings (
      setting_key VARCHAR(255) PRIMARY KEY, 
      setting_value TEXT,
      updated_by VARCHAR(255),
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS consultations (
      id VARCHAR(255) PRIMARY KEY,
      ticket_id VARCHAR(255),
      patient_id VARCHAR(255),
      doctor_id VARCHAR(255),
      doctor_name VARCHAR(255),
      patient_name VARCHAR(255),
      temperature VARCHAR(50),
      weight VARCHAR(50),
      blood_pressure VARCHAR(50),
      pulse VARCHAR(50),
      diagnosis TEXT,
      symptoms TEXT,
      prescription TEXT,
      lab_orders TEXT,
      notes TEXT,
      center_id VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS lab_results (
      id VARCHAR(255) PRIMARY KEY,
      test_name VARCHAR(255),
      category VARCHAR(255),
      patient_id VARCHAR(255),
      patient_name VARCHAR(255),
      doctor_id VARCHAR(255),
      doctor_name VARCHAR(255),
      result TEXT,
      status VARCHAR(50),
      center_id VARCHAR(255) DEFAULT 'center-001',
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS sales (
      id VARCHAR(255) PRIMARY KEY,
      patient_name VARCHAR(255),
      quantity INT,
      unit_price DECIMAL(10,2),
      total DECIMAL(10,2),
      status VARCHAR(50),
      center_id VARCHAR(255) DEFAULT 'center-001',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    await query(`CREATE TABLE IF NOT EXISTS centers (
      id VARCHAR(255) PRIMARY KEY,
      name VARCHAR(255),
      address TEXT,
      phone VARCHAR(50),
      email VARCHAR(255),
      director_name VARCHAR(255),
      rnis VARCHAR(255),
      capacity INT,
      pispi_alias VARCHAR(255),
      is_active TINYINT(1) DEFAULT 0,
      activated_at TIMESTAMP NULL,
      activated_by VARCHAR(255) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);

    // FORCER LES COLONNES VITALES (Si les tables existaient déjà en version light)
    const vitalCols = [
      ['patients', 'firstName', 'VARCHAR(255)'],
      ['patients', 'lastName', 'VARCHAR(255)'],
      ['patients', 'age', 'INT'],
      ['patients', 'gender', 'VARCHAR(10)'],
      ['patients', 'phone', 'VARCHAR(50)'],
      ['patients', 'address', 'TEXT'],
      ['patients', 'centerId', 'VARCHAR(255)'],
      ['tickets', 'patient_id', 'VARCHAR(255)'],
      ['tickets', 'amount', 'DECIMAL(10,2) DEFAULT 0.00'],
      ['tickets', 'payment_method', 'VARCHAR(50) DEFAULT "CASH"'],
      ['medicines', 'generic_name', 'VARCHAR(255)'],
      ['medicines', 'stock_quantity', 'INT DEFAULT 0'],
      ['medicines', 'center_id', 'VARCHAR(255) DEFAULT "center-001"'],
      ['medicines', 'centerId', 'VARCHAR(255)'],
      ['lab_results', 'center_id', 'VARCHAR(255) DEFAULT "center-001"'],
      ['sales', 'center_id', 'VARCHAR(255) DEFAULT "center-001"'],
      ['centers', 'is_active', 'TINYINT(1) DEFAULT 0'],
      ['centers', 'activated_at', 'TIMESTAMP NULL'],
      ['centers', 'activated_by', 'VARCHAR(255) NULL']
    ];
    for (const [t, c, d] of vitalCols) {
      try { await query(`ALTER TABLE ${t} ADD COLUMN ${c} ${d}`); } catch(e) {}
    }

    // Compatibilité multitenant : réinjecter center_id pour les données historiques
    // (anciens enregistrements sans center_id ou avec centerId uniquement)
    try {
      await query(`UPDATE patients SET center_id = COALESCE(NULLIF(center_id, ''), NULLIF(centerId, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE patients SET centerId = COALESCE(NULLIF(centerId, ''), NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE tickets SET center_id = COALESCE(NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE consultations SET center_id = COALESCE(NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE medicines SET center_id = COALESCE(NULLIF(center_id, ''), NULLIF(centerId, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE medicines SET centerId = COALESCE(NULLIF(centerId, ''), NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE lab_results SET center_id = COALESCE(NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}
    try {
      await query(`UPDATE sales SET center_id = COALESCE(NULLIF(center_id, ''), 'center-001')`);
    } catch (e) {}

    // Migrations en arrière-plan (le reste)
    async function runAsyncMigrations() {
      const sleep = (ms) => new Promise(r => setTimeout(r, ms));
      await sleep(5000);
      const cols = [
        ['tickets', 'patient_id', 'VARCHAR(255) AFTER ticket_number'],
        ['tickets', 'service_id', 'VARCHAR(255) AFTER patient_id'],
        ['tickets', 'doctor_id', 'VARCHAR(255) AFTER service_id'],
        ['tickets', 'patient_age', 'INT AFTER patient_name'],
        ['tickets', 'patient_gender', 'VARCHAR(10) AFTER patient_age'],
        ['tickets', 'patient_phone', 'VARCHAR(50) AFTER patient_gender'],
        ['tickets', 'patient_address', 'TEXT AFTER patient_phone'],
        ['tickets', 'amount', 'DECIMAL(10,2) DEFAULT 0.00 AFTER service_name'],
        ['tickets', 'payment_method', 'VARCHAR(50) DEFAULT "CASH" AFTER amount'],
        ['tickets', 'notes', 'TEXT AFTER payment_method'],
        ['patients', 'firstName', 'VARCHAR(255) AFTER name'],
        ['patients', 'lastName', 'VARCHAR(255) AFTER firstName'],
        ['patients', 'dateOfBirth', 'DATE AFTER lastName'],
        ['patients', 'gender', 'VARCHAR(10) AFTER dateOfBirth'],
        ['patients', 'phone', 'VARCHAR(20) AFTER gender'],
        ['patients', 'address', 'TEXT AFTER phone'],
        ['medicines', 'generic_name', 'VARCHAR(255) AFTER name'],
        ['medicines', 'stock', 'INT DEFAULT 0 AFTER stock_quantity'],
        ['medicines', 'min_stock_alert', 'INT DEFAULT 10 AFTER stock'],
        ['medicines', 'category', 'VARCHAR(255) DEFAULT "Général" AFTER stock']
      ];
      for (const [t, c, d] of cols) {
        try { await query(`ALTER TABLE ${t} ADD COLUMN ${c} ${d}`); } catch (e) { }
        await sleep(500);
      }
      // Index critiques pour améliorer les performances (ORDER BY / search)
      const indexList = [
        ['patients', 'idx_p_center', '(center_id)'],
        ['patients', 'idx_p_created', '(created_at)'],
        ['tickets', 'idx_t_center', '(center_id)'],
        ['tickets', 'idx_t_created', '(created_at)'],
        ['medicines', 'idx_m_name', '(name)'],
        ['medicines', 'idx_m_center', '(center_id)'],
        ['medicines', 'idx_m_created', '(created_at)'],
        ['consultations', 'idx_c_created', '(created_at)'],
        ['lab_results', 'idx_lab_created', '(created_at)'],
        ['sales', 'idx_sales_created', '(created_at)'],
        ['centers', 'idx_centers_active_created', '(is_active, created_at)']
      ];
      for (const [t, i, c] of indexList) {
        try { await query(`ALTER TABLE ${t} ADD INDEX ${i} ${c}`); } catch (e) { }
        await sleep(300);
      }
    }

    runAsyncMigrations().catch(e => console.error('Migration error:', e));

    logToFile("INIT: OK");
    return true;
  } catch (err) {
    dbErrorLog = err.message;
    logToFile(`ECHEC DB: ${err.message}`);
    return false;
  }
}

// MODELS
export class UserModel {
  static async findAll() { return await query('SELECT * FROM users ORDER BY name'); }
  static async findById(id) {
    const res = await query('SELECT * FROM users WHERE id = ?', [id]);
    return res[0] || null;
  }
  static async findByEmail(email) {
    const res = await query('SELECT * FROM users WHERE email = ?', [email]);
    return res;
  }
  static async create(data) {
    const id = data.id || `u-${Date.now()}`;
    await query(
      'INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)',
      [id, data.name, data.email, data.password || data.passwordHash, data.role || 'USER']
    );
    return await this.findById(id);
  }
}

export class PatientModel {
  static async findAll(centerId = null) {
    let q = 'SELECT * FROM patients';
    const params = [];
    if (centerId) {
      q += ' WHERE center_id = ? OR centerId = ?';
      params.push(centerId, centerId);
    }
    q += ' ORDER BY created_at DESC';
    const rows = await query(q, params);
    return rows.map(r => ({
      ...r,
      name: r.name || `${r.firstName || ''} ${r.lastName || ''}`.trim() || 'Inconnu',
      firstName: r.firstName || r.first_name || '',
      lastName: r.lastName || r.last_name || '',
      phoneNumber: r.phoneNumber || r.phone_number || r.phone || '',
      phone: r.phone || r.phoneNumber || r.phone_number || '',
      address: r.address || '',
      gender: r.gender || 'M'
    }));
  }
  static async findById(id) {
    const centerId = arguments[1] || null;
    const res = centerId
      ? await query('SELECT * FROM patients WHERE id = ? AND (center_id = ? OR centerId = ?)', [id, centerId, centerId])
      : await query('SELECT * FROM patients WHERE id = ?', [id]);
    return res[0] || null;
  }
  static async findByTicketNumber(ticketNumber) {
    return await query('SELECT * FROM patients WHERE ticket_number = ?', [ticketNumber]);
  }
  static async create(data) {
    const pid = data.id || `p-${Date.now()}`;
    const fullName = data.name || `${data.firstName || ''} ${data.lastName || ''}`.trim();
    const tenantCenterId = data.centerId || data.center_id || data.tenantId || 'center-001';
    await query(
      `INSERT INTO patients (id, name, firstName, lastName, age, gender, phone, address, center_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [pid, fullName, data.firstName || '', data.lastName || '', data.age || 0, data.gender || 'M', data.phone || '', data.address || '', tenantCenterId]
    );
    return await this.findById(pid);
  }
  static async update(id, data) {
    const centerId = arguments[2] || null;
    const updates = []; const params = [];
    Object.keys(data).forEach(k => {
      if (['name', 'firstName', 'lastName', 'age', 'gender', 'phone', 'address'].includes(k)) {
        updates.push(`${k} = ?`); params.push(data[k]);
      }
    });
    if (updates.length > 0) {
      params.push(id);
      if (centerId) {
        params.push(centerId, centerId);
        await query(`UPDATE patients SET ${updates.join(', ')} WHERE id = ? AND (center_id = ? OR centerId = ?)`, params);
      } else {
        await query(`UPDATE patients SET ${updates.join(', ')} WHERE id = ?`, params);
      }
    }
    return await this.findById(id, centerId);
  }
}

export class TicketModel {
  static async findAll(centerId = null) {
    const rows = centerId
      ? await query('SELECT * FROM tickets WHERE center_id = ? ORDER BY created_at DESC', [centerId])
      : await query('SELECT * FROM tickets ORDER BY created_at DESC');
    return rows.map(r => ({
      ...r,
      ticketNumber: r.ticket_number || r.ticketNumber || '',
      patientName: r.patient_name || r.patientName || 'Inconnu',
      patientAge: r.patient_age || r.patientAge || 0,
      patientGender: r.patient_gender || r.patientGender || 'M',
      serviceName: r.service_name || r.serviceName || 'Consultation',
      patientPhone: r.patient_phone || r.patientPhone || '',
      patientAddress: r.patient_address || r.patientAddress || '',
      status: r.status || 'WAITING',
      centerId: r.centerId || r.center_id || centerId || null,
      center_id: r.center_id || r.centerId || centerId || null,
      tenantId: r.tenantId || r.center_id || r.centerId || centerId || null
    }));
  }
  static async findById(id, centerId = null) {
    const res = centerId
      ? await query('SELECT * FROM tickets WHERE id = ? AND center_id = ?', [id, centerId])
      : await query('SELECT * FROM tickets WHERE id = ?', [id]);
    const r = res[0];
    if (!r) return null;
    return {
      ...r,
      ticketNumber: r.ticket_number || r.ticketNumber || '',
      patientName: r.patient_name || r.patientName || 'Inconnu',
      patientAge: r.patient_age || r.patientAge || 0,
      patientGender: r.patient_gender || r.patientGender || 'M',
      serviceName: r.service_name || r.serviceName || 'Consultation',
      patientPhone: r.patient_phone || r.patientPhone || '',
      patientAddress: r.patient_address || r.patientAddress || '',
      status: r.status || 'WAITING',
      centerId: r.centerId || r.center_id || centerId || null,
      center_id: r.center_id || r.centerId || centerId || null,
      tenantId: r.tenantId || r.center_id || r.centerId || centerId || null
    };
  }
  static async create(data) {
    const tid = data.id || `t-${Date.now()}`;
    const tenantCenterId = data.centerId || data.center_id || data.tenantId || 'center-001';
    await query(
      `INSERT INTO tickets (id, ticket_number, patient_name, patient_age, patient_gender, service_name, amount, status, center_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [tid, data.ticketNumber || `T-${Date.now()}`, data.patientName || '', data.patientAge || 0, data.patientGender || 'M', data.serviceName || 'Consultation', data.amount || 0, data.status || 'WAITING', tenantCenterId]
    );
    return await this.findById(tid);
  }
  static async updateStatus(id, status, doctorId = null) {
    if (doctorId) {
      await query('UPDATE tickets SET status = ?, doctor_id = ? WHERE id = ?', [status, doctorId, id]);
    } else {
      await query('UPDATE tickets SET status = ? WHERE id = ?', [status, id]);
    }
    return await this.findById(id);
  }
  static async getServices(ticketId) {
    return await query('SELECT * FROM ticket_services WHERE ticket_id = ?', [ticketId]);
  }
}

export class MedicineModel {
  static async findAll(centerId = null) {
    const rows = centerId
      ? await query('SELECT * FROM medicines WHERE (center_id = ? OR center_id IS NULL) ORDER BY name', [centerId])
      : await query('SELECT * FROM medicines ORDER BY name');
    return rows.map(r => ({
      ...r,
      name: r.name || 'Médicament sans nom',
      genericName: r.genericName || r.generic_name || r.dci || '',
      dci: r.dci || r.generic_name || '',
      category: r.category || 'Général',
      form: r.form || '',
      stock: r.stock_quantity || r.stock || 0,
      stock_quantity: r.stock_quantity || r.stock || 0,
      minStock: r.min_stock_alert || r.minStock || 10,
      min_stock_alert: r.min_stock_alert || r.minStock || 10,
      price: parseFloat(r.price || 0),
      centerId: r.centerId || r.center_id || centerId || 'center-001',
      center_id: r.center_id || r.centerId || centerId || 'center-001'
    }));
  }
  static async findById(id, centerId = null) {
    const res = centerId
      ? await query('SELECT * FROM medicines WHERE id = ? AND (center_id = ? OR center_id IS NULL)', [id, centerId])
      : await query('SELECT * FROM medicines WHERE id = ?', [id]);
    return res[0] || null;
  }
  static async create(data) {
    const mid = data.id || `m-${Date.now()}`;
    const tenantCenterId = data.centerId || data.center_id || data.tenantId || 'center-001';
    await query(
      `INSERT INTO medicines (id, name, generic_name, stock_quantity, price, center_id) VALUES (?, ?, ?, ?, ?, ?)`,
      [mid, data.name, data.genericName || '', data.stockQuantity || 0, data.price || 0, tenantCenterId]
    );
    return await this.findById(mid, tenantCenterId);
  }
}

// STUBS for missing but imported models
// STUBS for missing but imported models
export class ServiceModel {
  static async findAll(centerId = null) {
    return centerId
      ? await query('SELECT * FROM services WHERE (centerId = ? OR centerId IS NULL) ORDER BY createdAt DESC', [centerId])
      : await query('SELECT * FROM services ORDER BY createdAt DESC');
  }
  static async findById(id) {
    const res = await query('SELECT * FROM services WHERE id = ?', [id]);
    return res[0] || null;
  }
  static async create(d) {
    const id = d.id || `service-${Date.now()}`;
    await query(
      `INSERT INTO services (id, name, description, category, price, durationMinutes, color, centerId) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, d.name, d.description || '', d.category || 'Consultation', parseFloat(d.price || 0), parseInt(d.durationMinutes || 30), d.color || '#3b82f6', d.centerId || 'center-001']
    );
    return await this.findById(id);
  }
}
export class ConsultationModel {
  static async findAll(filters = {}) {
    let q = 'SELECT * FROM consultations';
    const params = [];
    const where = [];
    if (filters.patientId) { where.push('patient_id = ?'); params.push(filters.patientId); }
    if (filters.patient_id) { where.push('patient_id = ?'); params.push(filters.patient_id); }
    if (filters.doctorId) { where.push('doctor_id = ?'); params.push(filters.doctorId); }
    if (filters.doctor_id) { where.push('doctor_id = ?'); params.push(filters.doctor_id); }
    if (filters.centerId) { where.push('center_id = ?'); params.push(filters.centerId); }
    if (filters.center_id) { where.push('center_id = ?'); params.push(filters.center_id); }
    
    if (where.length > 0) q += ' WHERE ' + where.join(' AND ');
    q += ' ORDER BY created_at DESC';
    
    const rows = await query(q, params);
    return rows.map(r => ({
      ...r,
      ticketId: r.ticket_id,
      patientId: r.patient_id,
      doctorId: r.doctor_id,
      doctorName: r.doctor_name || 'Inconnu',
      patientName: r.patient_name || 'Inconnu',
      diagnosis: r.diagnosis || '',
      symptoms: r.symptoms || '',
      bloodPressure: r.blood_pressure || '',
      notes: r.notes || '',
      labOrders: r.lab_orders || '[]'
    }));
  }
  static async findById(id, centerId = null) {
    const res = centerId
      ? await query('SELECT * FROM consultations WHERE id = ? AND center_id = ?', [id, centerId])
      : await query('SELECT * FROM consultations WHERE id = ?', [id]);
    if (!res[0]) return null;
    const r = res[0];
    return {
      ...r,
      ticketId: r.ticket_id,
      patientId: r.patient_id,
      doctorId: r.doctor_id,
      doctorName: r.doctor_name,
      patientName: r.patient_name,
      bloodPressure: r.blood_pressure,
      labOrders: r.lab_orders
    };
  }
  static async create(d) {
    const id = d.id || `consult-${Date.now()}`;
    const tenantCenterId = d.centerId || d.center_id || d.tenantId || 'center-001';
    const ticketId = d.ticketId || d.ticket_id || null;
    const patientId = d.patientId || d.patient_id || null;
    const doctorId = d.doctorId || d.doctor_id || null;
    const doctorName = d.doctorName || d.doctor_name || null;
    const patientName = d.patientName || d.patient_name || null;
    const bloodPressure = d.bloodPressure || d.blood_pressure || null;
    const labOrders = d.labOrders || d.lab_orders || null;

    // Idempotence: a ticket should map to a single consultation in a center.
    // If it already exists, update it instead of inserting a duplicate row.
    if (ticketId) {
      const existing = await query(
        'SELECT id FROM consultations WHERE ticket_id = ? AND center_id = ? ORDER BY created_at DESC LIMIT 1',
        [ticketId, tenantCenterId]
      );
      if (existing && existing[0]?.id) {
        const existingId = existing[0].id;
        await query(
          `UPDATE consultations
           SET patient_id = ?, doctor_id = ?, doctor_name = ?, patient_name = ?, temperature = ?, weight = ?, blood_pressure = ?, pulse = ?, diagnosis = ?, symptoms = ?, prescription = ?, lab_orders = ?, notes = ?
           WHERE id = ?`,
          [patientId, doctorId, doctorName, patientName, d.temperature, d.weight, bloodPressure, d.pulse, d.diagnosis, d.symptoms, d.prescription, labOrders, d.notes, existingId]
        );
        return await this.findById(existingId, tenantCenterId);
      }
    }

    await query(
      `INSERT INTO consultations (id, ticket_id, patient_id, doctor_id, doctor_name, patient_name, temperature, weight, blood_pressure, pulse, diagnosis, symptoms, prescription, lab_orders, notes, center_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, ticketId, patientId, doctorId, doctorName, patientName, d.temperature, d.weight, bloodPressure, d.pulse, d.diagnosis, d.symptoms, d.prescription, labOrders, d.notes, tenantCenterId]
    );
    return await this.findById(id);
  }
}
export class SettingsModel {
  static async getAll() {
    const rows = await query('SELECT setting_key, setting_value FROM settings');
    const settings = {};
    rows.forEach(r => { settings[r.setting_key] = r.setting_value; });
    return settings;
  }
  static async get(key, fallback = null) {
    const res = await query('SELECT setting_value FROM settings WHERE setting_key = ?', [key]);
    return (res && res.length > 0) ? res[0].setting_value : fallback;
  }
  static async set(key, val, updatedBy = 'system') {
    const value = typeof val === 'object' ? JSON.stringify(val) : String(val);
    await query(
      `INSERT INTO settings (setting_key, setting_value, updated_by) VALUES (?, ?, ?) 
       ON DUPLICATE KEY UPDATE setting_value = ?, updated_by = ?`,
      [key, value, updatedBy, value, updatedBy]
    );
    return true;
  }
}
export class LabResultModel {
  static async findAll(filters = {}) {
    let q = 'SELECT * FROM lab_results';
    const params = [];
    const where = [];
    if (filters.patientId) { where.push('patient_id = ?'); params.push(filters.patientId); }
    if (filters.centerId) { where.push('center_id = ?'); params.push(filters.centerId); }
    if (filters.center_id) { where.push('center_id = ?'); params.push(filters.center_id); }
    if (where.length > 0) q += ' WHERE ' + where.join(' AND ');
    q += ' ORDER BY created_at DESC';
    const rows = await query(q, params);
    return rows.map(r => ({
      ...r,
      testName: r.test_name || r.testName || 'Examen sans nom',
      patientId: r.patient_id || r.patientId || '',
      patientName: r.patient_name || r.patientName || 'Inconnu',
      doctorId: r.doctor_id || r.doctorId || '',
      doctorName: r.doctor_name || r.doctorName || 'Inconnu',
      status: r.status || 'PENDING'
    }));
  }
  static async create(d) {
    const id = d.id || `lab-${Date.now()}`;
    const tenantCenterId = d.centerId || d.center_id || d.tenantId || 'center-001';
    await query(
      `INSERT INTO lab_results (id, test_name, category, patient_id, patient_name, doctor_id, doctor_name, result, status, notes, center_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, d.testName || d.test_name, d.category, d.patientId || d.patient_id, d.patientName || d.patient_name, d.doctorId || d.doctor_id, d.doctorName || d.doctor_name, d.result, d.status, d.notes, tenantCenterId]
    );
    return await this.findById(id, tenantCenterId);
  }
  static async findById(id, centerId = null) {
    const res = centerId
      ? await query('SELECT * FROM lab_results WHERE id = ? AND center_id = ?', [id, centerId])
      : await query('SELECT * FROM lab_results WHERE id = ?', [id]);
    if (!res[0]) return null;
    const r = res[0];
    return {
      ...r,
      testName: r.test_name,
      patientId: r.patient_id,
      patientName: r.patient_name,
      doctorId: r.doctor_id,
      doctorName: r.doctor_name
    };
  }
  static async update(id, data) {
    const centerId = arguments[2] || null;
    const updates = []; const params = [];
    Object.keys(data).forEach(k => {
      const dbKey = k === 'testName' ? 'test_name' : (k === 'patientId' ? 'patient_id' : (k === 'patientName' ? 'patient_name' : (k === 'doctorId' ? 'doctor_id' : (k === 'doctorName' ? 'doctor_name' : k))));
      if (['test_name', 'category', 'patient_id', 'patient_name', 'doctor_id', 'doctor_name', 'result', 'status', 'notes'].includes(dbKey)) {
        updates.push(`${dbKey} = ?`); params.push(data[k]);
      }
    });
    if (updates.length > 0) {
      params.push(id);
      if (centerId) {
        params.push(centerId);
        await query(`UPDATE lab_results SET ${updates.join(', ')} WHERE id = ? AND center_id = ?`, params);
      } else {
        await query(`UPDATE lab_results SET ${updates.join(', ')} WHERE id = ?`, params);
      }
    }
    return await this.findById(id, centerId);
  }
}
export class CenterModel {
  static async findAll(includeInactive = true) {
    if (includeInactive) {
      return await query("SELECT * FROM centers ORDER BY created_at DESC");
    }
    return await query("SELECT * FROM centers WHERE is_active = 1 ORDER BY created_at DESC");
  }
  static async findById(id) {
    const res = await query('SELECT * FROM centers WHERE id = ?', [id]);
    return res[0] || null;
  }
  static async create(d) {
    const id = d.id || `center-${Date.now()}`;
    const isActive = d.isActive || d.is_active ? 1 : 0;
    await query(
      `INSERT INTO centers (id, name, address, phone, email, director_name, rnis, capacity, pispi_alias, is_active) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, d.name, d.address, d.phone, d.email, d.directorName || d.director_name, d.rnis, d.capacity || 0, d.pispiAlias || d.pispi_alias, isActive]
    );
    return await this.findById(id);
  }

  static async setActivation(id, isActive, actorId = null) {
    await query(
      'UPDATE centers SET is_active = ?, activated_at = ?, activated_by = ? WHERE id = ?',
      [isActive ? 1 : 0, isActive ? new Date() : null, isActive ? actorId : null, id]
    );
    return await this.findById(id);
  }
}

export class SalesModel {
  static async findAll(centerId = null) {
    try {
      return centerId
        ? await query('SELECT * FROM sales WHERE center_id = ? ORDER BY created_at DESC', [centerId])
        : await query('SELECT * FROM sales ORDER BY created_at DESC');
    } catch (e) {
      // Fallback si la colonne created_at manque (migration)
      return centerId
        ? await query('SELECT * FROM sales WHERE center_id = ? ORDER BY id DESC', [centerId])
        : await query('SELECT * FROM sales ORDER BY id DESC');
    }
  }
}

export default { 
  initializeDatabase, 
  query, 
  transaction, 
  UserModel, 
  TicketModel, 
  PatientModel, 
  MedicineModel, 
  ServiceModel,
  ConsultationModel,
  LabResultModel,
  SettingsModel,
  CenterModel,
  SalesModel,
  getDbErrorLog 
};
