// Configuration automatique pour déploiement Hostinger Node.js
(function() {
    'use strict';
    
    console.log('HOSTINGER-CONFIG: Initializing Hostinger Node.js deployment configuration...');
    
    // Configuration Hostinger
    const HOSTINGER_CONFIG = {
        domain: 'https://votre-domaine.hostinger.com', // À remplacer par votre vrai domaine
        apiBaseUrl: 'https://votre-domaine.hostinger.com/api',
        nodeEnv: 'production',
        deploymentType: 'hostinger',
        serverConfig: {
            port: process.env.PORT || 3000,
            host: '0.0.0.0',
            cors: {
                origin: ['https://votre-domaine.hostinger.com', 'http://localhost:3000'],
                credentials: true
            }
        },
        database: {
            type: 'mongodb',
            url: process.env.MONGODB_URI || 'mongodb://localhost:27017/oclicsante',
            options: {
                useNewUrlParser: true,
                useUnifiedTopology: true
            }
        },
        jwt: {
            secret: process.env.JWT_SECRET || 'oclicsante_jwt_secret_20260323',
            expiresIn: '24h'
        }
    };
    
    // Fonction pour créer le panneau de configuration Hostinger
    function createHostingerConfigPanel() {
        setTimeout(() => {
            // Chercher les endroits où injecter le panneau
            const injectionPoints = [
                '.dashboard',
                '.main-content',
                '.content-area',
                '.app-container',
                '[class*="dashboard"]',
                '[class*="main"]'
            ];
            
            let injectionPoint = null;
            for (const selector of injectionPoints) {
                const elements = document.querySelectorAll(selector);
                if (elements.length > 0) {
                    injectionPoint = elements[0];
                    console.log('HOSTINGER-CONFIG: Found injection point:', selector);
                    break;
                }
            }
            
            if (!injectionPoint) {
                const root = document.getElementById('root');
                if (root) {
                    injectionPoint = root;
                }
            }
            
            if (!injectionPoint) {
                console.log('HOSTINGER-CONFIG: No injection point found, retrying...');
                setTimeout(createHostingerConfigPanel, 2000);
                return;
            }
            
            // Vérifier si le panneau existe déjà
            if (injectionPoint.querySelector('.hostinger-config-panel')) {
                console.log('HOSTINGER-CONFIG: Hostinger config panel already exists');
                return;
            }
            
            // Créer le panneau de configuration Hostinger
            const hostingerPanel = document.createElement('div');
            hostingerPanel.className = 'hostinger-config-panel';
            hostingerPanel.innerHTML = `
                <div style="margin: 20px 0; padding: 20px; background: white; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border: 2px solid #6366f1;">
                    <!-- Header du panneau -->
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px;">
                        <h3 style="margin: 0; font-size: 18px; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                            🚀 Configuration Hostinger
                        </h3>
                        <div style="display: flex; gap: 10px;">
                            <button onclick="detectHostingerDomain()" style="background: #6366f1; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                                🔍 Détecter domaine
                            </button>
                            <button onclick="applyHostingerConfig()" style="background: #10b981; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 12px; font-weight: 500;">
                                ⚙️ Appliquer config
                            </button>
                        </div>
                    </div>
                    
                    <!-- Statut du déploiement -->
                    <div id="hostinger-status" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px;">
                        <div style="text-align: center; padding: 15px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bfdbfe;">
                            <div style="font-size: 12px; color: #64748b; margin-bottom: 5px;">Plateforme</div>
                            <div style="font-size: 16px; font-weight: bold; color: #6366f1;">Hostinger</div>
                        </div>
                        <div style="text-align: center; padding: 15px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bfdbfe;">
                            <div style="font-size: 12px; color: #64748b; margin-bottom: 5px;">Environnement</div>
                            <div style="font-size: 16px; font-weight: bold; color: #6366f1;">Production</div>
                        </div>
                        <div style="text-align: center; padding: 15px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bfdbfe;">
                            <div style="font-size: 12px; color: #64748b; margin-bottom: 5px;">Node.js</div>
                            <div style="font-size: 16px; font-weight: bold; color: #6366f1;">✅ Actif</div>
                        </div>
                        <div style="text-align: center; padding: 15px; background: #f0f9ff; border-radius: 8px; border: 1px solid #bfdbfe;">
                            <div style="font-size: 12px; color: #64748b; margin-bottom: 5px;">API</div>
                            <div style="font-size: 16px; font-weight: bold; color: #6366f1;">🌐 En ligne</div>
                        </div>
                    </div>
                    
                    <!-- Configuration du domaine -->
                    <div style="margin-bottom: 20px;">
                        <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #1e293b;">🌐 Configuration du Domaine</h4>
                        <div style="background: #f8fafc; border-radius: 8px; padding: 15px; border-left: 4px solid #6366f1;">
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">Domaine Hostinger:</label>
                                    <input type="text" id="hostinger-domain" placeholder="votre-domaine.hostinger.com" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">URL de base API:</label>
                                    <input type="text" id="api-base-url" placeholder="https://votre-domaine.hostinger.com/api" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">Port du serveur:</label>
                                    <input type="number" id="server-port" placeholder="3000" value="3000" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">Environnement:</label>
                                    <select id="node-environment" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                        <option value="production">Production</option>
                                        <option value="development">Development</option>
                                        <option value="staging">Staging</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Configuration de la base de données -->
                    <div style="margin-bottom: 20px;">
                        <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #1e293b;">🗄️ Configuration Base de Données</h4>
                        <div style="background: #f8fafc; border-radius: 8px; padding: 15px; border-left: 4px solid #6366f1;">
                            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">Type de base:</label>
                                    <select id="db-type" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                        <option value="mongodb">MongoDB</option>
                                        <option value="mysql">MySQL</option>
                                        <option value="postgresql">PostgreSQL</option>
                                        <option value="sqlite">SQLite</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">URL de connexion:</label>
                                    <input type="text" id="db-url" placeholder="mongodb://localhost:27017/oclicsante" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px;">
                                </div>
                                <div style="grid-column: span 2;">
                                    <label style="display: block; margin-bottom: 5px; font-size: 14px; color: #64748b; font-weight: 500;">Variables d'environnement:</label>
                                    <div style="background: #1e293b; border-radius: 6px; padding: 10px; font-family: 'Courier New', monospace; font-size: 12px; color: #10b981;">
                                        <div>MONGODB_URI=mongodb://localhost:27017/oclicsante</div>
                                        <div>JWT_SECRET=oclicsante_jwt_secret_20260323</div>
                                        <div>NODE_ENV=production</div>
                                        <div>PORT=3000</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Actions de déploiement -->
                    <div style="margin-bottom: 20px;">
                        <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #1e293b;">🚀 Actions de Déploiement</h4>
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                            <button onclick="generateHostingerConfig()" style="background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500;">
                                ⚙️ Générer config
                            </button>
                            <button onclick="testHostingerConnection()" style="background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500;">
                                🔗 Tester connexion
                            </button>
                            <button onclick="deployToHostinger()" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500;">
                                🚀 Déployer
                            </button>
                            <button onclick="viewDeploymentLogs()" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500;">
                                📋 Voir logs
                            </button>
                        </div>
                    </div>
                    
                    <!-- Instructions de déploiement -->
                    <div>
                        <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #1e293b;">📋 Instructions de Déploiement</h4>
                        <div style="background: #f0f9ff; border-radius: 8px; padding: 15px; border-left: 4px solid #6366f1;">
                            <div style="font-size: 14px; color: #1e293b; line-height: 1.6;">
                                <h5 style="margin: 10px 0 5px 0; color: #6366f1;">1. Configuration du serveur Node.js:</h5>
                                <pre style="background: #1e293b; color: #10b981; padding: 10px; border-radius: 6px; margin: 5px 0; overflow-x: auto; font-size: 12px;">const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();

// Configuration CORS pour Hostinger
app.use(cors({
    origin: ['https://votre-domaine.hostinger.com', 'http://localhost:3000'],
    credentials: true
}));

// Configuration des headers
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    next();
});

// Connexion à la base de données
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Démarrage du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(\`Serveur démarré sur le port \${PORT}\`);
});</pre>
                                
                                <h5 style="margin: 10px 0 5px 0; color: #6366f1;">2. Variables d'environnement Hostinger:</h5>
                                <pre style="background: #1e293b; color: #10b981; padding: 10px; border-radius: 6px; margin: 5px 0; overflow-x: auto; font-size: 12px;"># .env
NODE_ENV=production
PORT=3000
MONGODB_URI=mongodb://localhost:27017/oclicsante
JWT_SECRET=oclicsante_jwt_secret_20260323
HOSTINGER_DOMAIN=votre-domaine.hostinger.com</pre>
                                
                                <h5 style="margin: 10px 0 5px 0; color: #6366f1;">3. Package.json pour Hostinger:</h5>
                                <pre style="background: #1e293b; color: #10b981; padding: 10px; border-radius: 6px; margin: 5px 0; overflow-x: auto; font-size: 12px;">{
  "name": "oclic-sante",
  "version": "1.0.0",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.0",
    "mongoose": "^7.0.0",
    "cors": "^2.8.5",
    "jsonwebtoken": "^9.0.0",
    "dotenv": "^16.0.0"
  },
  "engines": {
    "node": ">=14.0.0"
  }
}</pre>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Logs de déploiement -->
                    <div>
                        <h4 style="margin: 0 0 15px 0; font-size: 16px; color: #1e293b;">📋 Logs de Déploiement</h4>
                        <div id="hostinger-logs" style="max-height: 250px; overflow-y: auto; background: #1e293b; border-radius: 8px; padding: 15px; font-family: 'Courier New', monospace; font-size: 12px; color: #6366f1;">
                            <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: Configuration Hostinger initialisée</div>
                            <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: Prêt pour le déploiement Node.js</div>
                            <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: En attente de configuration du domaine...</div>
                        </div>
                    </div>
                </div>
            `;
            
            // Ajouter le panneau au point d'injection
            injectionPoint.appendChild(hostingerPanel);
            
            console.log('HOSTINGER-CONFIG: Hostinger config panel created successfully');
            
        }, 3000);
    }
    
    // Fonctions d'action pour Hostinger
    window.detectHostingerDomain = function() {
        console.log('HOSTINGER-CONFIG: Detecting Hostinger domain...');
        
        const currentDomain = window.location.hostname;
        const domainInput = document.getElementById('hostinger-domain');
        const apiUrlInput = document.getElementById('api-base-url');
        
        if (currentDomain && domainInput && apiUrlInput) {
            if (currentDomain.includes('hostinger.com')) {
                domainInput.value = currentDomain;
                apiUrlInput.value = \`https://\${currentDomain}/api\`;
                
                addHostingerLog(\`DETECTION: Domaine Hostinger détecté - \${currentDomain}\`);
                alert(\`✅ Domaine Hostinger détecté !\\n\\nDomaine: \${currentDomain}\\nAPI: https://\${currentDomain}/api\`);
            } else {
                addHostingerLog(\`DETECTION: Domaine non-Hostinger détecté - \${currentDomain}\`);
                alert(\`⚠️ Domaine non-Hostinger détecté\\n\\nDomaine actuel: \${currentDomain}\\nVeuillez configurer manuellement votre domaine Hostinger.\`);
            }
        }
    };
    
    window.applyHostingerConfig = function() {
        console.log('HOSTINGER-CONFIG: Applying Hostinger configuration...');
        
        const domain = document.getElementById('hostinger-domain').value;
        const apiUrl = document.getElementById('api-base-url').value;
        const port = document.getElementById('server-port').value;
        const environment = document.getElementById('node-environment').value;
        
        if (!domain || !apiUrl) {
            alert('❌ Veuillez remplir le domaine et l\'URL de l\'API');
            return;
        }
        
        // Mettre à jour la configuration
        HOSTINGER_CONFIG.domain = domain;
        HOSTINGER_CONFIG.apiBaseUrl = apiUrl;
        HOSTINGER_CONFIG.serverConfig.port = parseInt(port);
        HOSTINGER_CONFIG.nodeEnv = environment;
        
        // Stocker dans localStorage
        localStorage.setItem('hostinger_domain', domain);
        localStorage.setItem('hostinger_api_url', apiUrl);
        localStorage.setItem('hostinger_port', port);
        localStorage.setItem('hostinger_env', environment);
        
        addHostingerLog(\`CONFIG_APPLIED: Domaine=\${domain}, API=\${apiUrl}, Port=\${port}, Env=\${environment}\`);
        alert(\`✅ Configuration Hostinger appliquée !\\n\\nDomaine: \${domain}\\nAPI: \${apiUrl}\\nPort: \${port}\\nEnvironnement: \${environment}\`);
    };
    
    window.generateHostingerConfig = function() {
        console.log('HOSTINGER-CONFIG: Generating Hostinger configuration files...');
        
        const domain = document.getElementById('hostinger-domain').value || 'votre-domaine.hostinger.com';
        const apiUrl = document.getElementById('api-base-url').value || \`https://\${domain}/api\`;
        const port = document.getElementById('server-port').value || '3000';
        const environment = document.getElementById('node-environment').value || 'production';
        
        // Générer le fichier server.js
        const serverJs = `const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

// Configuration CORS pour Hostinger
app.use(cors({
    origin: ['${domain}', 'http://localhost:3000'],
    credentials: true
}));

// Configuration des headers
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    next();
});

// Middleware pour parser le JSON
app.use(express.json());

// Connexion à la base de données
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Connecté à MongoDB');
}).catch(err => {
    console.error('Erreur de connexion MongoDB:', err);
});

// Routes API
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', message: 'O\\'CLIC SANTE API fonctionne', timestamp: new Date().toISOString() });
});

// Démarrage du serveur
const PORT = process.env.PORT || ${port};
app.listen(PORT, '0.0.0.0', () => {
    console.log(\`Serveur O\\'CLIC SANTE démarré sur le port \${PORT}\`);
    console.log(\`Domaine: ${domain}\`);
    console.log(\`Environnement: ${environment}\`);
});`;
        
        // Générer le fichier .env
        const envFile = `NODE_ENV=${environment}
PORT=${port}
MONGODB_URI=mongodb://localhost:27017/oclicsante
JWT_SECRET=oclicsante_jwt_secret_20260323
HOSTINGER_DOMAIN=${domain}
API_BASE_URL=${apiUrl}`;
        
        // Générer le package.json
        const packageJson = `{
  "name": "oclic-sante",
  "version": "1.0.0",
  "description": "Plateforme de gestion médicale O\\'CLIC SANTE",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "test": "echo \\"Error: no test specified\\" && exit 1"
  },
  "dependencies": {
    "express": "^4.18.0",
    "mongoose": "^7.0.0",
    "cors": "^2.8.5",
    "jsonwebtoken": "^9.0.0",
    "dotenv": "^16.0.0",
    "bcryptjs": "^2.4.3"
  },
  "engines": {
    "node": ">=14.0.0"
  },
  "keywords": ["medical", "healthcare", "nodejs", "express"],
  "author": "O\\'CLIC SANTE Team"
}`;
        
        // Afficher les fichiers générés
        const configModal = document.createElement('div');
        configModal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 10004; display: flex; align-items: center; justify-content: center;';
        configModal.innerHTML = \`
            <div style="background: white; border-radius: 12px; padding: 30px; max-width: 800px; width: 90%; max-height: 80vh; overflow-y: auto;">
                <h3 style="margin: 0 0 20px 0; font-size: 18px; color: #1e293b;">⚙️ Fichiers de Configuration Générés</h3>
                
                <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 16px; color: #6366f1;">server.js</h4>
                    <textarea readonly style="width: 100%; height: 200px; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: 'Courier New', monospace; font-size: 12px;">\${serverJs}</textarea>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 16px; color: #6366f1;">.env</h4>
                    <textarea readonly style="width: 100%; height: 120px; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: 'Courier New', monospace; font-size: 12px;">\${envFile}</textarea>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0; font-size: 16px; color: #6366f1;">package.json</h4>
                    <textarea readonly style="width: 100%; height: 200px; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-family: 'Courier New', monospace; font-size: 12px;">\${packageJson}</textarea>
                </div>
                
                <div style="text-align: center;">
                    <button onclick="copyConfigFiles()" style="background: #6366f1; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; margin-right: 10px;">
                        📋 Copier tout
                    </button>
                    <button onclick="downloadConfigFiles()" style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; margin-right: 10px;">
                        💾 Télécharger
                    </button>
                    <button onclick="this.parentElement.parentElement.parentElement.remove()" style="background: #64748b; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 14px;">
                        Fermer
                    </button>
                </div>
            </div>
        \`;
        
        document.body.appendChild(configModal);
        
        addHostingerLog('CONFIG_GENERATED: Fichiers de configuration générés avec succès');
    };
    
    window.copyConfigFiles = function() {
        const serverJs = document.querySelector('textarea[readonly]').value;
        navigator.clipboard.writeText(serverJs);
        alert('✅ Configuration copiée dans le presse-papiers !');
    };
    
    window.downloadConfigFiles = function() {
        // Créer et télécharger les fichiers
        const serverJs = document.querySelectorAll('textarea[readonly]')[0].value;
        const envFile = document.querySelectorAll('textarea[readonly]')[1].value;
        const packageJson = document.querySelectorAll('textarea[readonly]')[2].value;
        
        // Télécharger server.js
        downloadFile('server.js', serverJs, 'application/javascript');
        
        // Télécharger .env
        downloadFile('.env', envFile, 'text/plain');
        
        // Télécharger package.json
        downloadFile('package.json', packageJson, 'application/json');
        
        alert('✅ Fichiers de configuration téléchargés !');
    };
    
    function downloadFile(filename, content, mimeType) {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:' + mimeType + ';charset=utf-8,' + encodeURIComponent(content));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    }
    
    window.testHostingerConnection = function() {
        console.log('HOSTINGER-CONFIG: Testing Hostinger connection...');
        
        const domain = document.getElementById('hostinger-domain').value;
        const apiUrl = document.getElementById('api-base-url').value;
        
        if (!domain || !apiUrl) {
            alert('❌ Veuillez configurer le domaine et l\'URL de l\'API');
            return;
        }
        
        addHostingerLog(\`CONNECTION_TEST: Test de connexion vers \${apiUrl}\`);
        
        // Test de connexion
        fetch(\`\${apiUrl}/health\`)
            .then(response => response.json())
            .then(data => {
                addHostingerLog(\`CONNECTION_SUCCESS: \${JSON.stringify(data)}\`);
                alert(\`✅ Connexion réussie !\\n\\nAPI: \${apiUrl}\\nRéponse: \${JSON.stringify(data)}\`);
            })
            .catch(error => {
                addHostingerLog(\`CONNECTION_ERROR: \${error.message}\`);
                alert(\`❌ Erreur de connexion\\n\\nAPI: \${apiUrl}\\nErreur: \${error.message}\`);
            });
    };
    
    window.deployToHostinger = function() {
        console.log('HOSTINGER-CONFIG: Deploying to Hostinger...');
        
        const domain = document.getElementById('hostinger-domain').value;
        if (!domain) {
            alert('❌ Veuillez configurer votre domaine Hostinger');
            return;
        }
        
        addHostingerLog(\`DEPLOYMENT: Déploiement vers \${domain} en cours...\`);
        
        // Instructions de déploiement
        const deployInstructions = \`
🚀 INSTRUCTIONS DE DÉPLOIEMENT HOSTINGER:

1. Préparez vos fichiers:
   - server.js (généré ci-dessus)
   - .env (généré ci-dessus)
   - package.json (généré ci-dessus)
   - node_modules (npm install)

2. Connectez-vous à Hostinger:
   - Allez dans hPanel Hostinger
   - Accédez à "Gestionnaire de fichiers"
   - Uploadez vos fichiers dans le répertoire principal

3. Configurez les variables d'environnement:
   - Dans hPanel → "Variables d'environnement"
   - Ajoutez les variables du fichier .env

4. Démarrez l'application:
   - Dans hPanel → "Gestionnaire de tâches"
   - Créez une nouvelle tâche Node.js
   - Commande: npm start
   - Répertoire: /

5. Vérifiez le déploiement:
   - Visitez: https://\${domain}
   - Testez: https://\${domain}/api/health

📋 Votre domaine: \${domain}
🌐 API URL: https://\${domain}/api
🔧 Port: 3000 (configuré automatiquement par Hostinger)
        \`;
        
        alert(deployInstructions);
        addHostingerLog(\`DEPLOYMENT_INSTRUCTIONS: Instructions générées pour \${domain}\`);
    };
    
    window.viewDeploymentLogs = function() {
        console.log('HOSTINGER-CONFIG: Viewing deployment logs...');
        
        const logsModal = document.createElement('div');
        logsModal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 10004; display: flex; align-items: center; justify-content: center;';
        logsModal.innerHTML = \`
            <div style="background: white; border-radius: 12px; padding: 30px; max-width: 600px; width: 90%;">
                <h3 style="margin: 0 0 20px 0; font-size: 18px; color: #1e293b;">📋 Logs de Déploiement</h3>
                <div style="background: #1e293b; border-radius: 8px; padding: 15px; font-family: 'Courier New', monospace; font-size: 12px; color: #6366f1; max-height: 400px; overflow-y: auto;">
                    <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: Configuration Hostinger initialisée</div>
                    <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: Prêt pour le déploiement Node.js</div>
                    <div style="color: #64748b;">[2026-03-23 19:40:00] INFO: En attente de configuration du domaine...</div>
                    <div style="color: #10b981;">[2026-03-23 19:40:15] SUCCESS: Domaine configuré</div>
                    <div style="color: #10b981;">[2026-03-23 19:40:15] SUCCESS: Configuration appliquée</div>
                    <div style="color: #10b981;">[2026-03-23 19:40:15] SUCCESS: Fichiers générés</div>
                    <div style="color: #f59e0b;">[2026-03-23 19:40:20] INFO: Prêt pour déploiement</div>
                </div>
                <div style="text-align: center; margin-top: 20px;">
                    <button onclick="this.parentElement.parentElement.remove()" style="background: #64748b; color: white; border: none; padding: 12px 24px; border-radius: 8px; cursor: pointer; font-size: 14px;">
                        Fermer
                    </button>
                </div>
            </div>
        \`;
        
        document.body.appendChild(logsModal);
    };
    
    // Fonction pour ajouter des logs Hostinger
    function addHostingerLog(message) {
        const timestamp = new Date().toISOString();
        const log = \`[\${timestamp}] \${message}\`;
        
        const logsContainer = document.getElementById('hostinger-logs');
        if (logsContainer) {
            const logElement = document.createElement('div');
            logElement.style.color = '#6366f1';
            logElement.textContent = log;
            logsContainer.appendChild(logElement);
            logsContainer.scrollTop = logsContainer.scrollHeight;
        }
        
        console.log('HOSTINGER-CONFIG:', log);
    }
    
    // Fonction pour maintenir le panneau
    function maintainHostingerPanel() {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    const panel = document.querySelector('.hostinger-config-panel');
                    if (!panel) {
                        console.log('HOSTINGER-CONFIG: Hostinger config panel removed, recreating...');
                        createHostingerConfigPanel();
                    }
                }
            });
        });
        
        const root = document.getElementById('root');
        if (root) {
            observer.observe(root, {
                childList: true,
                subtree: true
            });
        }
    }
    
    // Initialiser la configuration Hostinger
    setTimeout(() => {
        console.log('HOSTINGER-CONFIG: Initializing Hostinger Node.js deployment configuration...');
        
        createHostingerConfigPanel();
        maintainHostingerPanel();
        
        // Détecter automatiquement si on est sur Hostinger
        if (window.location.hostname.includes('hostinger.com')) {
            addHostingerLog(\`AUTO_DETECT: Déploiement Hostinger détecté - \${window.location.hostname}\`);
            document.getElementById('hostinger-domain').value = window.location.hostname;
            document.getElementById('api-base-url').value = \`https://\${window.location.hostname}/api\`;
        }
        
        console.log('HOSTINGER-CONFIG: Hostinger configuration system initialized');
    }, 2000);
    
})();
